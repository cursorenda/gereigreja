# configuracao/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
# Importar User e login
from django.contrib.auth import login
from django.contrib.auth.models import User
# Importar transaction
from django.db import transaction
from .models import Igreja, Organizacao, PerfilUsuario # Certifique-se que PerfilUsuario está importado
from .forms import IgrejaForm, OrganizacaoForm, RegistroAdminOrgForm # Importe os forms necessários

# --- View de Registro para Administrador da Organização (ATUALIZADA) ---
def registro_admin_org_view(request):
    if request.user.is_authenticated:
        # Se o usuário já está logado, redireciona para o dashboard/home
        messages.info(request, "Você já está logado.")
        return redirect('index') # Ajuste 'index' se o nome da sua URL principal for outro

    if request.method == 'POST':
        form = RegistroAdminOrgForm(request.POST)
        if form.is_valid():
            # Usar transaction.atomic para garantir que todas as operações no banco
            # sejam realizadas com sucesso, ou nenhuma delas.
            try:
                with transaction.atomic():
                    # 1. Obter dados limpos do formulário
                    username = form.cleaned_data['username']
                    email = form.cleaned_data['email']
                    password = form.cleaned_data['password']
                    nome_organizacao = form.cleaned_data['nome_organizacao']
                    nome_igreja_sede = form.cleaned_data['nome_igreja_sede']
                    # Obtenha outros campos se os adicionou ao form (ex: cnpj_organizacao, cidade_sede)
                    # cnpj_organizacao = form.cleaned_data.get('cnpj_organizacao') # .get() é mais seguro se o campo for opcional

                    # 2. Criar o Usuário Administrador
                    user = User.objects.create_user(username=username, email=email, password=password)
                    # Você pode definir nome/sobrenome se coletar no form
                    # user.first_name = ...
                    # user.last_name = ...
                    # user.save()

                    # 3. Criar a Organização
                    # O 'administrador_principal' é o usuário que acabamos de criar
                    organizacao = Organizacao.objects.create(
                        nome=nome_organizacao,
                        administrador_principal=user,
                        ativo=False # Começa inativa, aguardando aprovação do superuser/dev
                        # Adicione outros campos se necessário (ex: cnpj=cnpj_organizacao)
                    )

                    # 4. Criar a Igreja Sede
                    # A 'organizacao' é a que acabamos de criar
                    igreja_sede = Igreja.objects.create(
                        organizacao=organizacao,
                        nome_igreja=nome_igreja_sede,
                        tipo_igreja='sede' # Define como SEDE
                        # Adicione outros campos se necessário (ex: cidade=cidade_sede)
                    )

                    # 5. Criar o Perfil do Usuário
                    # Liga o 'user' à 'organizacao'
                    perfil = PerfilUsuario.objects.create(
                        user=user,
                        organizacao=organizacao
                    )

                # 6. Fazer o login do usuário recém-criado
                login(request, user)

                # 7. Mensagem de sucesso e redirecionamento
                messages.success(request, f'Bem-vindo, {user.username}! Sua organização "{organizacao.nome}" foi criada e aguarda aprovação para acesso completo.')
                # Redireciona para o dashboard ou página inicial
                return redirect('index') # Ajuste se necessário

            except Exception as e:
                # Captura qualquer erro inesperado durante a transação
                messages.error(request, f'Ocorreu um erro inesperado durante o registro: {e}. Por favor, tente novamente ou contate o suporte.')
                # Logar o erro também seria bom aqui:
                import logging
                logger = logging.getLogger(__name__)
                logger.exception("Erro no registro de Admin Org")
                # Não redireciona, permite que o usuário veja o erro e tente corrigir o form
        else:
            # Se o formulário não for válido, os erros já foram adicionados pelo Django
            messages.error(request, 'Por favor, corrija os erros no formulário abaixo.')
    else:
        # Se for um GET, apenas cria um formulário em branco
        form = RegistroAdminOrgForm()

    # Renderiza o template com o formulário (seja GET ou POST inválido)
    return render(request, 'configuracao/registro_admin_org.html', {'form': form})


# --- View Principal de Configuração (Lista Igrejas) ---
@login_required
def configuracao_view(request):
    """
    View principal de configuração. Lista as igrejas da organização do usuário logado.
    """
    try:
        perfil = request.user.perfil
        organizacao = perfil.organizacao
        if not organizacao:
            messages.error(request, "Seu usuário não está associado a nenhuma organização.")
            # Se for superuser, talvez redirecionar para uma visão geral?
            if request.user.is_superuser:
                 return redirect('admin:index') # Ex: para o admin do Django
            return redirect('index')

        # Verifica se a organização está ativa (opcional, mas recomendado)
        if not organizacao.ativo and not request.user.is_superuser:
             messages.warning(request, f'Sua organização "{organizacao.nome}" ainda não foi aprovada. Algumas funcionalidades podem estar limitadas.')
             # Você pode decidir se limita o acesso aqui ou apenas mostra a mensagem

        igrejas = Igreja.objects.filter(organizacao=organizacao).order_by('tipo_igreja', 'nome_igreja')

        context = {
            'organizacao': organizacao,
            'igrejas': igrejas,
            'organizacao_ativa': organizacao.ativo # Passa o status para o template
        }
        return render(request, 'configuracao/lista_igrejas.html', context)

    except PerfilUsuario.DoesNotExist:
        if request.user.is_superuser:
             messages.info(request, "Como Superusuário, você não tem uma organização padrão. Use o painel Admin para gerenciar organizações.")
             return redirect('admin:index') # Redireciona superuser para o admin
        else:
             # Situação inesperada: usuário logado sem perfil.
             messages.error(request, "Erro crítico: Perfil de usuário não encontrado. Contate o suporte.")
             # Talvez deslogar o usuário? Ou redirecionar para uma página de erro?
             return redirect('index') # Ou para o login?

    except Exception as e:
        messages.error(request, f"Ocorreu um erro inesperado ao carregar as configurações: {e}")
        import logging
        logger = logging.getLogger(__name__)
        logger.exception("Erro em configuracao_view")
        return redirect('index')

# --- Views Adicionais (CRUD de Igrejas) ---

@login_required
def adicionar_igreja(request):
    """ View para adicionar uma nova igreja à organização do usuário. """
    try:
        organizacao = request.user.perfil.organizacao
        if not organizacao:
             messages.error(request, "Usuário sem organização associada.")
             return redirect('configuracao:configuracao')

        # Opcional: Verificar se a organização está ativa
        # if not organizacao.ativo and not request.user.is_superuser:
        #    messages.error(request, "Sua organização precisa estar ativa para adicionar igrejas.")
        #    return redirect('configuracao:configuracao')

        if request.method == 'POST':
            # Passa a 'organizacao' para o __init__ do form para filtrar 'igreja_superior'
            form = IgrejaForm(request.POST, request.FILES, organizacao=organizacao)
            if form.is_valid():
                # Define a organização antes de salvar (pois foi excluída do form)
                nova_igreja = form.save(commit=False)
                nova_igreja.organizacao = organizacao
                nova_igreja.save()
                messages.success(request, f'Igreja "{nova_igreja.nome_igreja}" adicionada com sucesso!')
                return redirect('configuracao:configuracao') # Volta para a lista
            else:
                messages.error(request, "Erro ao adicionar igreja. Verifique os campos.")
        else:
            # GET: Cria um form em branco, passando a organização para o __init__
            form = IgrejaForm(organizacao=organizacao)

        context = {
            'form': form,
            'titulo_pagina': 'Adicionar Nova Igreja',
            'nome_botao': 'Adicionar'
        }
        # Reutiliza o template de configuração/edição se ele for genérico o suficiente
        # ou cria um template específico 'adicionar_igreja.html'
        return render(request, 'configuracao/form_igreja.html', context) # Ajuste o nome do template se necessário

    except PerfilUsuario.DoesNotExist:
         messages.error(request, "Perfil de usuário não encontrado.")
         return redirect('index')
    except Exception as e:
        messages.error(request, f"Ocorreu um erro ao tentar adicionar a igreja: {e}")
        import logging
        logger = logging.getLogger(__name__)
        logger.exception("Erro em adicionar_igreja")
        return redirect('configuracao:configuracao')


@login_required
def editar_igreja(request, igreja_id):
    """ View para editar uma igreja existente. """
    try:
        organizacao = request.user.perfil.organizacao
        if not organizacao:
             messages.error(request, "Usuário sem organização associada.")
             return redirect('configuracao:configuracao')

        # Garante que a igreja a ser editada pertence à organização do usuário
        igreja = get_object_or_404(Igreja, pk=igreja_id, organizacao=organizacao)

        if request.method == 'POST':
            # Passa instance=igreja e a organização para o form
            form = IgrejaForm(request.POST, request.FILES, instance=igreja, organizacao=organizacao)
            if form.is_valid():
                igreja_editada = form.save()
                messages.success(request, f'Igreja "{igreja_editada.nome_igreja}" atualizada com sucesso!')
                return redirect('configuracao:configuracao') # Volta para a lista
            else:
                messages.error(request, "Erro ao atualizar igreja. Verifique os campos.")
        else:
            # GET: Cria o form preenchido com os dados da instância, passando a organização
            form = IgrejaForm(instance=igreja, organizacao=organizacao)

        context = {
            'form': form,
            'igreja': igreja, # Passa a instância para o template, se necessário
            'titulo_pagina': f'Editar Igreja: {igreja.nome_igreja}',
            'nome_botao': 'Salvar Alterações'
        }
        # Reutiliza o template de configuração/edição
        return render(request, 'configuracao/form_igreja.html', context) # Ajuste o nome do template se necessário

    except PerfilUsuario.DoesNotExist:
         messages.error(request, "Perfil de usuário não encontrado.")
         return redirect('index')
    except Igreja.DoesNotExist:
         messages.error(request, "Igreja não encontrada ou não pertence à sua organização.")
         return redirect('configuracao:configuracao')
    except Exception as e:
        messages.error(request, f"Ocorreu um erro ao tentar editar a igreja: {e}")
        import logging
        logger = logging.getLogger(__name__)
        logger.exception(f"Erro em editar_igreja (ID: {igreja_id})")
        return redirect('configuracao:configuracao')


@login_required
def excluir_igreja(request, igreja_id):
    """ View para excluir uma igreja (requer confirmação, idealmente via POST). """
    try:
        organizacao = request.user.perfil.organizacao
        if not organizacao:
             messages.error(request, "Usuário sem organização associada.")
             return redirect('configuracao:configuracao')

        # Garante que a igreja a ser excluída pertence à organização do usuário
        igreja = get_object_or_404(Igreja, pk=igreja_id, organizacao=organizacao)

        # --- IMPORTANTE: Segurança ---
        # Idealmente, a exclusão deve ser feita via método POST após uma confirmação.
        # O link na tabela (GET com JS confirm) é menos seguro.
        # Vamos implementar a lógica básica aqui, mas considere refatorar para POST.
        if request.method == 'POST': # Se você mudar o link/botão para usar POST
            try:
                nome_igreja = igreja.nome_igreja
                # Verificar se a igreja a ser excluída é a SEDE (talvez impedir?)
                if igreja.tipo_igreja == 'sede':
                     # Verificar se existem outras igrejas na organização
                     if Igreja.objects.filter(organizacao=organizacao).exclude(pk=igreja_id).exists():
                          messages.error(request, "Não é possível excluir a Igreja Sede enquanto houver outras igrejas na organização.")
                          return redirect('configuracao:configuracao')
                     # Se for a única igreja, talvez permitir, mas avisar que a organização ficará sem sede?

                # Verificar se há igrejas subordinadas (talvez reatribuir ou impedir?)
                if igreja.igrejas_subordinadas.exists():
                    messages.error(request, f"Não é possível excluir '{nome_igreja}' pois ela possui igrejas subordinadas. Reatribua as igrejas subordinadas primeiro.")
                    return redirect('configuracao:configuracao')

                igreja.delete()
                messages.success(request, f'Igreja "{nome_igreja}" excluída com sucesso!')
            except Exception as e:
                 messages.error(request, f"Erro ao excluir a igreja '{igreja.nome_igreja}': {e}")
            return redirect('configuracao:configuracao') # Volta para a lista após POST

        # Se for GET (como está atualmente com o link da tabela):
        # Apenas executa a exclusão (menos seguro, mas funciona com o JS confirm)
        try:
            nome_igreja = igreja.nome_igreja
            if igreja.tipo_igreja == 'sede':
                 if Igreja.objects.filter(organizacao=organizacao).exclude(pk=igreja_id).exists():
                      messages.error(request, "Não é possível excluir a Igreja Sede enquanto houver outras igrejas na organização.")
                      return redirect('configuracao:configuracao')
            if igreja.igrejas_subordinadas.exists():
                messages.error(request, f"Não é possível excluir '{nome_igreja}' pois ela possui igrejas subordinadas. Reatribua as igrejas subordinadas primeiro.")
                return redirect('configuracao:configuracao')

            igreja.delete()
            messages.success(request, f'Igreja "{nome_igreja}" excluída com sucesso!')
        except Exception as e:
            messages.error(request, f"Erro ao excluir a igreja '{igreja.nome_igreja}': {e}")

        return redirect('configuracao:configuracao') # Volta para a lista após GET

    except PerfilUsuario.DoesNotExist:
         messages.error(request, "Perfil de usuário não encontrado.")
         return redirect('index')
    except Igreja.DoesNotExist:
         messages.error(request, "Igreja não encontrada ou não pertence à sua organização.")
         return redirect('configuracao:configuracao')
    except Exception as e:
        messages.error(request, f"Ocorreu um erro ao tentar excluir a igreja: {e}")
        import logging
        logger = logging.getLogger(__name__)
        logger.exception(f"Erro em excluir_igreja (ID: {igreja_id})")
        return redirect('configuracao:configuracao')

# --- Fim das Views de Configuração ---