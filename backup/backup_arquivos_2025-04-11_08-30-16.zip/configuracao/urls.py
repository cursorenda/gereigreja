# configuracao/urls.py
from django.urls import path
from . import views

app_name = 'configuracao' # Define o namespace

urlpatterns = [
    # URL de Registro (já deve existir)
    path('registrar/', views.registro_admin_org_view, name='registrar'),

    # URL Principal de Configuração (agora lista as igrejas)
    path('', views.configuracao_view, name='configuracao'), # Aponta para a view refatorada

    # URLs para CRUD de Igrejas
    path('igreja/adicionar/', views.adicionar_igreja, name='adicionar_igreja'),
    path('igreja/editar/<int:igreja_id>/', views.editar_igreja, name='editar_igreja'),
    path('igreja/excluir/<int:igreja_id>/', views.excluir_igreja, name='excluir_igreja'),

    # Outras URLs que você possa ter (login, etc., podem estar no urls.py principal)
]
