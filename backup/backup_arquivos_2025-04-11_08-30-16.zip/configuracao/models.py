# c:\Gereigreja\configuracao\models.py
from django.db import models
from django.conf import settings # Necessário para referenciar o User model padrão do Django

# --- Modelo para a Organização/Ministério ---
# Representa a entidade maior que um "Administrador da Organização" gerencia.
class Organizacao(models.Model):
    nome = models.CharField(
        max_length=200,
        unique=True, # Garante que não haja duas organizações com o mesmo nome
        verbose_name="Nome da Organização/Ministério"
    )
    administrador_principal = models.ForeignKey(
        settings.AUTH_USER_MODEL, # Link para o usuário Django que é o admin principal
        on_delete=models.PROTECT, # Impede excluir um usuário se ele for admin de uma organização
        related_name='organizacoes_administradas',
        verbose_name="Administrador Principal"
    )
    data_criacao = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Data de Criação"
    )
    ativo = models.BooleanField(
        default=False, # Começa como inativo por padrão
        verbose_name="Ativo (Aprovado pelo Desenvolvedor)",
        help_text="Organizações inativas podem ter acesso limitado até serem aprovadas."
    )
    # Você pode adicionar outros campos aqui depois (ex: plano de assinatura, etc.)
    cnpj = models.CharField(max_length=18, unique=True, null=True, blank=True, verbose_name="CNPJ") # Exemplo: único, opcional

    def __str__(self):
        return self.nome

    class Meta:
        verbose_name = "Organização"
        verbose_name_plural = "Organizações"
        ordering = ['nome'] # Ordena as organizações por nome por padrão

# --- Modelo para o Perfil do Usuário ---
# Estende o User padrão do Django, ligando-o a uma Organização.
class PerfilUsuario(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE, # Se o User for excluído, o Perfil também é
        primary_key=True, # Usa o ID do User como chave primária do Perfil
        related_name='perfil', # Permite acessar o perfil via 'request.user.perfil'
        verbose_name="Usuário"
    )
    organizacao = models.ForeignKey(
        Organizacao,
        on_delete=models.CASCADE, # Se a Organização for excluída, os perfis associados também são
        related_name='membros_equipe', # Permite acessar membros via 'organizacao.membros_equipe.all()'
        verbose_name="Organização"
    )
    # Adicione outros campos específicos do perfil se necessário (cargo, telefone, etc.)
    # O papel (Admin, Usuário da Igreja) será gerenciado pelos Grupos do Django.

    def __str__(self):
        # Tenta retornar o nome completo, senão o username
        return self.user.get_full_name() or self.user.username

    class Meta:
        verbose_name = "Perfil de Usuário"
        verbose_name_plural = "Perfis de Usuários"

# --- Modelo para cada Igreja (Sede, Regional, Congregação) ---
# RENOMEADO de IgrejaConfiguracao para Igreja
class Igreja(models.Model):
    # --- Ligação Fundamental ---
    organizacao = models.ForeignKey(
        Organizacao,
        on_delete=models.CASCADE, # Se a Organização for excluída, suas igrejas também são
        related_name='igrejas', # Permite acessar igrejas via 'organizacao.igrejas.all()'
        verbose_name="Organização"
        # Este campo será preenchido automaticamente na view, não pelo usuário diretamente no form.
    )

    # --- Tipos de Igreja ---
    TIPO_IGREJA_CHOICES = [
        ('sede', 'Sede'),
        ('regional', 'Regional'),
        ('congregacao', 'Congregação'),
    ]
    tipo_igreja = models.CharField(
        max_length=20,
        choices=TIPO_IGREJA_CHOICES,
        default='congregacao',
        verbose_name="Tipo de Igreja"
    )

    # --- Relacionamento Hierárquico (Dentro da mesma Organização) ---
    igreja_superior = models.ForeignKey(
        'self', # Aponta para o próprio modelo Igreja
        on_delete=models.SET_NULL, # Se a igreja superior for deletada, define este campo como nulo
        null=True, # Permite nulo (para Sedes ou se a superior for deletada)
        blank=True, # Permite ficar em branco no formulário
        related_name='igrejas_subordinadas',
        verbose_name="Igreja Superior (Sede/Regional)",
        help_text="Selecione a Sede ou Regional à qual esta igreja está vinculada (se aplicável)."
        # A filtragem para mostrar apenas igrejas da mesma organização será feita no formulário (forms.py)
    )

    # --- Informações da Igreja ---
    nome_igreja = models.CharField(max_length=255, verbose_name="Nome da Igreja")

    # --- Endereço ---
    rua = models.CharField(max_length=255, blank=True, null=True, verbose_name="Rua")
    numero = models.CharField(max_length=10, blank=True, null=True, verbose_name="Número")
    complemento = models.CharField(max_length=100, blank=True, null=True, verbose_name="Complemento")
    bairro = models.CharField(max_length=255, blank=True, null=True, verbose_name="Bairro")
    cidade = models.CharField(max_length=100, blank=True, null=True, verbose_name="Cidade")
    estado = models.CharField(max_length=50, blank=True, null=True, verbose_name="Estado")
    pais = models.CharField(max_length=50, blank=True, null=True, default="Brasil", verbose_name="País")
    cep = models.CharField(max_length=9, blank=True, null=True, verbose_name="CEP")

    # --- Contato e Documentos ---
    email = models.EmailField(blank=True, null=True, verbose_name="E-mail")
    cnpj = models.CharField(max_length=18, blank=True, null=True, verbose_name="CNPJ")
    telefone = models.CharField(max_length=20, blank=True, null=True, verbose_name="Telefone")
    celular = models.CharField(max_length=20, blank=True, null=True, verbose_name="Celular")
    site = models.URLField(blank=True, null=True, verbose_name="Site")

    # --- Responsáveis (Manter como CharField por enquanto para simplificar) ---
    pastor_local = models.CharField(max_length=255, blank=True, null=True, verbose_name="Pastor Local / Responsável")
    pastor_regional = models.CharField(max_length=255, blank=True, null=True, verbose_name="Pastor Regional") # Avaliar necessidade futura

    # --- Outras Configurações ---
    moeda = models.CharField(max_length=3, default="BRL", verbose_name="Moeda")
    observacoes = models.TextField(blank=True, null=True, verbose_name="Observações")
    logo1 = models.ImageField(upload_to='logos/', blank=True, null=True, verbose_name="Logo 1")
    logo2 = models.ImageField(upload_to='logos/', blank=True, null=True, verbose_name="Logo 2")

    def __str__(self):
        # Retorna nome, tipo e organização para fácil identificação
        return f"{self.nome_igreja} ({self.get_tipo_igreja_display()}) - [{self.organizacao.nome}]"

    class Meta:
        verbose_name = "Igreja" # RENOMEADO
        verbose_name_plural = "Igrejas" # RENOMEADO
        ordering = ['organizacao', 'nome_igreja'] # Ordena primeiro por organização, depois por nome
        # Considere adicionar uma restrição de unicidade se necessário, por exemplo:
        # unique_together = ('organizacao', 'nome_igreja') # Garante nome único dentro da organização
