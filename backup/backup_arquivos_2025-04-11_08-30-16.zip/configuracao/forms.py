# c:\Gereigreja\configuracao\forms.py
from django import forms
from .models import Igreja, Organizacao, PerfilUsuario # Modelos necessários
from django.contrib.auth.models import User # Modelo de usuário padrão
from django.db import transaction # Para garantir atomicidade no registro

class IgrejaForm(forms.ModelForm):
    """
    Formulário para criar ou editar uma Igreja.
    """
    class Meta:
        model = Igreja
        # Exclui 'organizacao' pois será definida automaticamente pela view
        # com base no usuário logado.
        exclude = ['organizacao']
        widgets = {
            # Adiciona classes CSS do Bootstrap para estilização
            'nome_igreja': forms.TextInput(attrs={'class': 'form-control'}),
            'tipo_igreja': forms.Select(attrs={'class': 'form-select'}),
            'igreja_superior': forms.Select(attrs={'class': 'form-select'}), # Será filtrado no __init__
            'cep': forms.TextInput(attrs={'class': 'form-control'}),
            'rua': forms.TextInput(attrs={'class': 'form-control'}),
            'numero': forms.TextInput(attrs={'class': 'form-control'}),
            'complemento': forms.TextInput(attrs={'class': 'form-control'}),
            'bairro': forms.TextInput(attrs={'class': 'form-control'}),
            'cidade': forms.TextInput(attrs={'class': 'form-control'}),
            'estado': forms.Select(attrs={'class': 'form-select'}), # Assumindo que você tem choices no model ou ajustará aqui
            'pais': forms.TextInput(attrs={'class': 'form-control'}),
            'telefone': forms.TextInput(attrs={'class': 'form-control'}),
            'celular': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'cnpj': forms.TextInput(attrs={'class': 'form-control'}),
            'site': forms.URLInput(attrs={'class': 'form-control'}),
            'pastor_local': forms.TextInput(attrs={'class': 'form-control'}),
            'pastor_regional': forms.TextInput(attrs={'class': 'form-control'}),
            'moeda': forms.TextInput(attrs={'class': 'form-control'}),
            'observacoes': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'logo1': forms.ClearableFileInput(attrs={'class': 'form-control'}),
            'logo2': forms.ClearableFileInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        """
        Sobrescreve o __init__ para filtrar o campo 'igreja_superior'.
        Espera receber um argumento 'organizacao' da view.
        """
        # Remove 'organizacao' dos kwargs antes de chamar o super()
        organizacao = kwargs.pop('organizacao', None)
        super().__init__(*args, **kwargs)

        # Filtra o queryset de 'igreja_superior'
        if organizacao:
            # Mostra apenas igrejas da mesma organização, excluindo a própria igreja (se for edição)
            queryset = Igreja.objects.filter(organizacao=organizacao)
            if self.instance and self.instance.pk:
                queryset = queryset.exclude(pk=self.instance.pk)
            self.fields['igreja_superior'].queryset = queryset
        else:
            # Se não houver organização (ex: erro ou caso inesperado), não mostra nenhuma opção
             self.fields['igreja_superior'].queryset = Igreja.objects.none()

        # Torna igreja_superior não obrigatório (já definido no model com null=True, blank=True)
        # Mas podemos reforçar aqui se necessário.
        self.fields['igreja_superior'].required = False


class RegistroAdminOrgForm(forms.Form):
    """
    Formulário para o registro inicial de um Administrador e sua Organização/Igreja Sede.
    Este formulário NÃO salva diretamente os modelos, a lógica de criação
    dos objetos (User, Organizacao, Igreja, PerfilUsuario) deve estar na VIEW.
    """
    # Campos da Organização e Igreja Sede
    nome_organizacao = forms.CharField(
        max_length=100,
        label="Nome da Organização/Convenção",
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    nome_igreja_sede = forms.CharField(
        max_length=100,
        label="Nome da Igreja Sede",
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    # Adicione outros campos se desejar coletar mais dados no registro
    # Ex: cnpj_organizacao = forms.CharField(max_length=18, required=False, label="CNPJ da Organização", widget=forms.TextInput(attrs={'class': 'form-control'}))
    # Ex: cidade_sede = forms.CharField(max_length=100, required=False, label="Cidade da Sede", widget=forms.TextInput(attrs={'class': 'form-control'}))

    # Campos do Usuário Administrador
    username = forms.CharField(
        max_length=100,
        label="Nome de Usuário (Admin)",
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    email = forms.EmailField(
        label="Email (Admin)",
        widget=forms.EmailInput(attrs={'class': 'form-control'})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
        label="Senha (Admin)"
    )
    confirm_password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
        label="Confirmar Senha (Admin)"
    )

    def clean_username(self):
        """ Validação específica para o username. """
        username = self.cleaned_data.get('username')
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("Este nome de usuário já está em uso.")
        return username

    def clean_email(self):
        """ Validação específica para o email. """
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("Este email já está cadastrado.")
        return email

    def clean(self):
        """ Validação geral do formulário (ex: comparar senhas). """
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")

        # Verifica se os campos de senha existem antes de comparar
        if password and confirm_password and password != confirm_password:
            # Adiciona o erro ao campo 'confirm_password' para exibição
            self.add_error('confirm_password', "As senhas não coincidem.")
            # Poderia adicionar a 'password' também, se preferir
            # self.add_error('password', "As senhas não coincidem.")

        # Não precisa retornar cleaned_data explicitamente aqui se não modificar mais nada,
        # mas é boa prática.
        return cleaned_data

    # IMPORTANTE: Este formulário NÃO tem um método save() padrão.
    # A lógica de criar User, Organizacao, Igreja e PerfilUsuario
    # deve ser implementada na view 'registro_admin_org_view' usando os
    # dados de 'form.cleaned_data'.


class OrganizacaoForm(forms.ModelForm):
    """
    Formulário para editar os dados de uma Organização existente.
    """
    class Meta:
        model = Organizacao
        # Define quais campos podem ser editados. Exclua campos sensíveis
        # ou que não devem ser alterados pelo admin (ex: data_criacao, ativo - se controlado por superuser).
        fields = ['nome', 'cnpj'] # Exemplo: permite editar nome e CNPJ
        # Ou use 'exclude = [...]' para listar os que NÃO devem aparecer.
        # exclude = ['administrador_principal', 'data_criacao', 'ativo']
        widgets = {
            # Adiciona classes CSS do Bootstrap
            'nome': forms.TextInput(attrs={'class': 'form-control'}),
            'cnpj': forms.TextInput(attrs={'class': 'form-control'}),
            # Adicione outros campos aqui se incluídos em 'fields'
        }

# Você pode adicionar outros formulários aqui conforme necessário,
# por exemplo, um formulário para editar o PerfilUsuario, etc.
