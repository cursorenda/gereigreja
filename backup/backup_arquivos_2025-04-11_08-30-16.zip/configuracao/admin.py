# c:\Gereigreja\configuracao\admin.py
from django.contrib import admin
# Importar os nomes corretos dos modelos
from .models import Organizacao, PerfilUsuario, Igreja
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User

# --- Admin para Organização ---
@admin.register(Organizacao)
class OrganizacaoAdmin(admin.ModelAdmin):
    list_display = ('nome', 'administrador_principal', 'data_criacao', 'ativo')
    list_filter = ('ativo', 'data_criacao')
    search_fields = ('nome', 'administrador_principal__username', 'administrador_principal__email')
    list_editable = ('ativo',)
    readonly_fields = ('data_criacao',)
    actions = ['aprovar_organizacoes', 'desativar_organizacoes']

    @admin.action(description='Aprovar organizações selecionadas')
    def aprovar_organizacoes(self, request, queryset):
        queryset.update(ativo=True)

    @admin.action(description='Desativar organizações selecionadas')
    def desativar_organizacoes(self, request, queryset):
        queryset.update(ativo=False)

# --- Admin para PerfilUsuario (Inline no User Admin) ---
class PerfilUsuarioInline(admin.StackedInline):
    model = PerfilUsuario
    can_delete = False
    verbose_name_plural = 'Perfil (Organização)'
    fk_name = 'user'

# Estender o UserAdmin padrão para incluir o PerfilUsuarioInline
class CustomUserAdmin(BaseUserAdmin):
    inlines = (PerfilUsuarioInline,)
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff', 'get_organizacao')
    list_select_related = ('perfil',)

    @admin.display(description='Organização')
    def get_organizacao(self, instance):
        try:
            return instance.perfil.organizacao
        except PerfilUsuario.DoesNotExist:
            return None
    get_organizacao.admin_order_field = 'perfil__organizacao'

# Desregistrar o UserAdmin padrão e registrar o nosso customizado
admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)


# --- Admin para Igreja (Atualizado e CORRIGIDO) ---
# REMOVIDO o @admin.register(Igreja) solto e o bloco de comentários duplicado daqui

@admin.register(Igreja) # MANTIDO APENAS ESTE DECORADOR, antes da classe
class IgrejaAdmin(admin.ModelAdmin):
    # --- Configurações da Lista ---
    list_display = (
        'nome_igreja',
        'organizacao',
        'tipo_igreja',
        'igreja_superior',
        'cidade',
        'estado',
        'pastor_local',
    )
    list_filter = ('organizacao', 'tipo_igreja', 'estado', 'pais')
    search_fields = ('nome_igreja', 'organizacao__nome', 'cidade', 'pastor_local', 'cnpj')
    list_select_related = ('organizacao', 'igreja_superior')

    # --- Configuração do Formulário de Edição/Adição ---
    fieldsets = (
        ('Informações Principais', {
            'fields': (
                'organizacao',
                'nome_igreja',
                ('tipo_igreja', 'igreja_superior')
            )
        }),
        ('Endereço', {
            'fields': (
                'cep', 'rua', ('numero', 'complemento'), ('bairro', 'cidade'), ('estado', 'pais')
            )
        }),
        ('Contatos e Documentos', {
            'fields': (
                ('telefone', 'celular'), ('email', 'cnpj'), 'site'
            )
        }),
        ('Responsáveis', {
            'fields': (
                ('pastor_local', 'pastor_regional'),
            )
        }),
        ('Outras Configurações', {
            'fields': (
                'moeda', 'observacoes', ('logo1', 'logo2')
            )
        }),
    )

    # Método para controlar campos readonly (correto como estava)
    def get_readonly_fields(self, request, obj=None):
        if obj:
            return ('organizacao',)
        else:
            return ()

    # Método para filtrar 'igreja_superior' (correto como estava)
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "igreja_superior":
            organizacao_id = request.POST.get('organizacao')
            obj_id = request.resolver_match.kwargs.get('object_id')

            if obj_id: # Editando
                try:
                    igreja_atual = self.get_object(request, obj_id)
                    if igreja_atual and igreja_atual.organizacao:
                        kwargs["queryset"] = Igreja.objects.filter(organizacao=igreja_atual.organizacao).exclude(pk=obj_id)
                    else:
                         kwargs["queryset"] = Igreja.objects.none()
                except Igreja.DoesNotExist:
                     kwargs["queryset"] = Igreja.objects.none()
            elif organizacao_id: # Adicionando (tentativa de pegar do POST)
                 kwargs["queryset"] = Igreja.objects.filter(organizacao_id=organizacao_id)
            else: # Adicionando, sem organização selecionada ainda
                kwargs["queryset"] = Igreja.objects.none()

        return super().formfield_for_foreignkey(db_field, request, **kwargs)

