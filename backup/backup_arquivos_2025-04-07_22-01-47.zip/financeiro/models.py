from django.db import models
from django.utils import timezone
from gerenciamento.models import Membro
from decimal import Decimal  # Importa a classe Decimal

class CategoriaDespesa(models.Model):
    """
    Modelo para representar uma categoria de Despesa.
    """
    nome = models.CharField(max_length=100, unique=True, verbose_name="Nome da Categoria")

    def __str__(self):
        return self.nome

    class Meta:
        db_table = 'categoria_despesa'
        verbose_name = "Categoria de Despesa"
        verbose_name_plural = "Categorias de Despesas"





class Despesas(models.Model):
    """
    Modelo para representar uma despesa.
    """
   
    data = models.DateField(verbose_name="Data")
    descricao = models.CharField(max_length=255, verbose_name="Descrição")
    valor = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Valor")
    categoria = models.ForeignKey(CategoriaDespesa, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Categoria")
    observacao = models.TextField(blank=True, null=True, verbose_name="Observação")  # Novo campo!
    fechado = models.BooleanField(default=False, verbose_name="Fechado")

    def __str__(self):
        return self.descricao

    class Meta:
        db_table = 'despesas'
        verbose_name = "Despesa"
        verbose_name_plural = "Despesas"







class Receitas(models.Model):
    """
    Modelo para representar uma receita.
    """
    CATEGORIA_CHOICES = [
        ('dizimo', 'Dízimo'),
        ('oferta', 'Oferta'),
        ('voto', 'Voto'),
        ('campanha', 'Campanha'),
    ]
    membro = models.ForeignKey(Membro, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='Membro')
    data = models.DateField(verbose_name="Data")
    valor = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Valor")
    observacao = models.TextField(blank=True, null=True, verbose_name="Observação")
    forma_pgto = models.TextField(blank=True, null=True, verbose_name="Forma de Pagamento")
    categoria = models.CharField(
        max_length=20,
        choices=CATEGORIA_CHOICES,
        default='dizimo',
        verbose_name="Categoria"
    )
    fechado = models.BooleanField(default=False, verbose_name="Fechado")

    class Meta:
        db_table = 'receitas'
        verbose_name = "Receita"
        verbose_name_plural = "Receitas"



class FechamentoCaixa(models.Model):
    """
    Modelo para representar um Fechamento de Caixa.
    """
    STATUS_CHOICES = [
        ('aberto', 'Aberto'),
        ('fechado', 'Fechado'),
        ('reaberto', 'Reaberto'),
    ]

    data_inicio = models.DateField(verbose_name="Data de Início")
    data_fim = models.DateField(verbose_name="Data de Fim")
    data_fechamento = models.DateTimeField(auto_now_add=True, verbose_name="Data do Fechamento")
    total_entradas = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Total de Entradas")
    total_saidas = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Total de Saídas")
    saldo_final = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Saldo Final")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='aberto', verbose_name="Status")
    ajuste = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Ajuste")
    sub_sede = models.CharField(max_length=255, blank=True, null=True) #Exemplo para campo de texto, ajuste conforme necessário
    congregacao = models.CharField(max_length=255, blank=True, null=True) #Exemplo para campo de texto, ajuste conforme necessári
    rua = models.CharField(max_length=255, blank=True, null=True, verbose_name="Rua")
    bairro = models.CharField(max_length=255, blank=True, null=True, verbose_name="Bairro") # Add this line

    def __str__(self):
        return f"Fechamento de {self.data_inicio} a {self.data_fim}"

    class Meta:
        db_table = 'fechamento_caixa'
        verbose_name = "Fechamento de Caixa"
        verbose_name_plural = "Fechamentos de Caixa"