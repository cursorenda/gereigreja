from django.urls import path
from . import views

app_name = 'financeiro'

urlpatterns = [
    path('despesas/', views.lista_despesas, name='lista_despesas'),
    path('despesas/cadastrar/', views.cadastrar_despesa, name='cadastrar_despesa'),
    path('despesas/editar/<int:pk>/', views.editar_despesa, name='editar_despesa'),
    path('receitas/', views.lista_receitas, name='lista_receitas'),
    path('receitas/cadastrar/', views.cadastrar_receita, name='cadastrar_receita'),
    path('receitas/editar/<int:pk>/', views.editar_receita, name='editar_receita'),

    # URLs para Fechamento de Caixa
    path('fechamentos/criar/', views.criar_fechamento_caixa, name='criar_fechamento_caixa'),
    path('fechamentos/', views.lista_fechamentos_caixa, name='lista_fechamentos_caixa'),
    path('fechamentos/<int:pk>/', views.detalhe_fechamento_caixa, name='detalhe_fechamento_caixa'),
    path('fechamentos/editar/<int:pk>/', views.editar_fechamento_caixa, name='editar_fechamento_caixa'),
    path('fechamento/<int:pk>/relatorio/', views.relatorio_mensal_detalhe, name='relatorio_financeiro_mensal'),

]
