from django import forms
from .models import Despesas, Receitas, FechamentoCaixa, CategoriaDespesa
from datetime import date
from django.forms import ModelChoiceField
from gerenciamento.models import Membro
from django.core.exceptions import ValidationError

class DespesaForm(forms.ModelForm):
    categoria = ModelChoiceField(queryset=CategoriaDespesa.objects.all(), required=True, widget=forms.Select(attrs={'class': 'form-control'}))
    class Meta:
        model = Despesas
        fields = ['data', 'categoria', 'descricao', 'valor', 'observacao']  # Ajustar campos se necessario
        widgets = {
            'data': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}), # para definir o tipo de data no input
            'descricao': forms.TextInput(attrs={'placeholder': 'Digite a descrição', 'class': 'form-control'}),
            'valor': forms.NumberInput(attrs={'placeholder': 'Digite o valor', 'class': 'form-control'}),
            'observacao': forms.Textarea(attrs={'placeholder': 'Digite a Observação', 'rows': 3, 'class': 'form-control'})
        }

    def __init__(self, *args, **kwargs):
        super(DespesaForm, self).__init__(*args, **kwargs)
        # Definir a data padrão para a data atual:
        self.fields['data'].initial = date.today()

    def clean_valor(self):
        valor = self.cleaned_data['valor']
        if valor <= 0:
            raise ValidationError("O valor deve ser positivo.")
        return valor

    def clean_data(self):
        data = self.cleaned_data['data']
        # Adicione aqui uma validação mais robusta para a data, se necessário.
        # Por exemplo, verificar se a data não é futura.
        return data


class ReceitaForm(forms.ModelForm):
    """
        Formulário para criar e editar Receitas
    """
    membro = ModelChoiceField(queryset=Membro.objects.all().order_by('nome'), required=False, widget=forms.Select(attrs={'class': 'form-control'}))
    class Meta:
        model = Receitas
        fields = ['membro', 'data', 'valor', 'observacao', 'forma_pgto', 'categoria']
        labels = {
            'membro': 'Nome do Membro',
            'data': 'Data',
            'valor': 'Valor',
            'observacao': 'Observação',
            'forma_pgto': 'Forma de Pagamento',
            'categoria': 'Categoria'
        }
        widgets = {
            'data': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'valor': forms.NumberInput(attrs={'placeholder': 'Digite o Valor', 'class': 'form-control'}),
            'observacao': forms.Textarea(attrs={'placeholder': 'Digite a Observação', 'rows': 3, 'class': 'form-control'}),
            'forma_pgto': forms.Select(choices=[('dinheiro', 'Dinheiro'), ('pix', 'Pix')], attrs={'class': 'form-control'}),
            'categoria': forms.Select(attrs={'class': 'form-control'}),
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Define a data atual como padrão
        self.fields['data'].initial = date.today()
        # Define o membro como autocomplete
        self.fields['membro'].widget.attrs.update({'class': 'form-control', 'id': 'id_membro'})

    def clean_valor(self):
        valor = self.cleaned_data['valor']
        if valor <= 0:
            raise ValidationError("O valor deve ser positivo.")
        return valor

    def clean_data(self):
        data = self.cleaned_data['data']
        # Adicione aqui uma validação mais robusta para a data, se necessário.
        return data
    

class FechamentoCaixaForm(forms.ModelForm):
    """
    Formulário para criar e editar Fechamentos de Caixa.
    """
    class Meta:
        model = FechamentoCaixa
        fields = ['data_inicio', 'data_fim']
        labels = {
            'data_inicio': 'Data de Início',
            'data_fim': 'Data de Fim',
        }
        widgets = {
            'data_inicio': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'data_fim': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
        }

