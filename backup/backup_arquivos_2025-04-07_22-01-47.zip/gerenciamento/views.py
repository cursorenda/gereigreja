from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Membro, Tiposstatus
from .forms import MembroForm
from django.http import HttpResponse
from datetime import datetime
from django.conf import settings
import os
import shutil
import logging
import zipfile
from django.db.models import Count
import json #DEIXE APENAS ESTE IMPORT!
from django.db.models import Case, When, Value, IntegerField
from django.db import models

# Configura o logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# Define o formato do log
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

# Define o manipulador de arquivo (para onde o log será escrito)
file_handler = logging.FileHandler('backup_log.txt')
file_handler.setFormatter(formatter)

# Adiciona o manipulador ao logger
logger.addHandler(file_handler)

def index(request):
    return render(request, 'gerenciamento/index.html')

def dashboard(request):
    # Dados do gráfico de status dos membros
    status_data = Tiposstatus.objects.annotate(total=Count('membro')).values('status', 'total')  # Query correta para Tiposstatus
    status_data_json = json.dumps(list(status_data))

    # Dados do gráfico de gênero dos membros
    genero_data = Membro.objects.values('genero').annotate(total=Count('genero')).order_by('genero')
    genero_data_json = json.dumps(list(genero_data))

    # Dados do gráfico de faixa etária dos membros
    faixa_etaria_data = Membro.objects.annotate(
            idade=(
                Case(
                 When(nascimento__isnull=False, then=models.Value(0)),
                    output_field=IntegerField(),
                )
            )
        ).annotate(
            faixa_etaria=Case(When(idade__lt=18, then=Value('Menor de 18')), When(idade__range=(18, 30), then=Value('18-30')), When(idade__range=(31, 50), then=Value('31-50')), default=Value('Mais de 50'), output_field=models.CharField())
        ).values('faixa_etaria').annotate(total=Count('chave')).order_by('faixa_etaria')
        
    faixa_etaria_data_json = json.dumps(list(faixa_etaria_data))


    context = {
        'status_data_json': status_data_json,
        'genero_data_json': genero_data_json,
        'faixa_etaria_data_json': faixa_etaria_data_json,
    }

    return render(request, 'dashboard.html', context)



def lista_membros(request):
    query = request.GET.get('q')
    if query:
        membros = Membro.objects.filter(nome__icontains=query)
    else:
        membros = Membro.objects.all()
    tipos_status = Tiposstatus.objects.all()
    return render(request, 'gerenciamento/lista_membros.html', {'membros': membros, 'tipos_status':tipos_status})

def editar_membro(request, membro_id):
    membro = get_object_or_404(Membro, pk=membro_id)
    if request.method == 'POST':
        form = MembroForm(request.POST, instance=membro)
        if form.is_valid():
            form.save()
            messages.success(request, 'Membro atualizado com sucesso!')
            return redirect('lista_membros')
    else:
        form = MembroForm(instance=membro)
    return render(request, 'gerenciamento/editar_membro.html', {'form': form, 'membro_id': membro_id})

def criar_membro(request):
    if request.method == 'POST':
        form = MembroForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Membro cadastrado com sucesso!')
            return redirect('lista_membros')
    else:
        form = MembroForm()
    return render(request, 'gerenciamento/criar_membro.html', {'form': form})


def backup_database():
    """
    Função para realizar o backup do banco de dados.
    """
    data_hora_atual = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')

    # Define o nome da pasta de backups
    backup_dir = os.path.join(settings.BASE_DIR, 'backup')

    # Garante que a pasta de backups exista. Se não existir, cria ela.
    os.makedirs(backup_dir, exist_ok=True)

    backup_file = f"backup_banco_{data_hora_atual}.sqlite3"

    # Agora o caminho para o backup será dentro da pasta 'backup'
    backup_path = os.path.join(backup_dir, backup_file)

    db_path = settings.DATABASES['default']['NAME']

    try:
        shutil.copy2(db_path, backup_path)
        logger.info(f"Backup do banco de dados realizado com sucesso em: {backup_path}")
        return True, backup_path
    except Exception as e:
        logger.error(f"Erro ao realizar backup do banco de dados: {e}")
        return False, None

def backup_site_files():
    """
    Função para realizar o backup dos arquivos do site.
    """
    data_hora_atual = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    backup_dir = os.path.join(settings.BASE_DIR, 'backup')
    os.makedirs(backup_dir, exist_ok=True)
    backup_file = f"backup_arquivos_{data_hora_atual}.zip"
    backup_path = os.path.join(backup_dir, backup_file)
    site_path = settings.BASE_DIR

    # Pastas a serem ignoradas no backup.
    folders_to_ignore = [
        os.path.join(settings.BASE_DIR, 'backup'),
        os.path.join(settings.BASE_DIR, 'static'), #pasta com muitos arquivos
        os.path.join(settings.BASE_DIR, '__pycache__'),#pasta desnecessaria
        os.path.join(settings.BASE_DIR, 'venv'), #pasta com arquivos da venv
    ]

    try:
        logger.info(f"Iniciando backup dos arquivos do site.")
        #Cria um novo arquivo zip, no modo escrita.
        with zipfile.ZipFile(backup_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        #percorre toda a pasta do projeto.
            for root, dirs, files in os.walk(site_path):
                # Verifica se a pasta atual está na lista para ignorar
                if any(os.path.join(root).startswith(folder) for folder in folders_to_ignore):
                    continue  # Ignora esta pasta e seus subitens

                for file in files:
                    file_path = os.path.join(root, file)

                    # Verifica se o arquivo faz parte de uma pasta para ignorar
                    if any(file_path.startswith(folder) for folder in folders_to_ignore):
                        continue  # Ignora este arquivo

                    #calcula o caminho do arquivo na raiz do projeto
                    relative_path = os.path.relpath(file_path, site_path)

                    #adiciona o arquivo ao zip
                    zipf.write(file_path, arcname=relative_path)

        logger.info(f"Backup dos arquivos do site realizado com sucesso em: {backup_path}")
        return True, backup_path
    except Exception as e:
        logger.error(f"Erro ao realizar backup dos arquivos do site: {e}")
        logger.error(f"Detalhes do erro: {e}")
        return False, None

def backup_page(request):
    if request.method == 'POST':
        fazer_backup_database = False
        fazer_backup_files = False

        # Verifica se os checkboxes foram marcados
        if 'backup_database' in request.POST:
            fazer_backup_database = True
        if 'backup_files' in request.POST:
            fazer_backup_files = True

        #Remove as mensagens pendentes.
        list(messages.get_messages(request))

        #verifica qual o backup a ser feito:
        if fazer_backup_database and fazer_backup_files:
            #executa os dois backups
            sucesso_db, caminho_db = backup_database()
            sucesso_files, caminho_files = backup_site_files()

            if sucesso_db and sucesso_files:
                messages.success(request, f'Backup Completo realizado com sucesso! <br>Banco de dados salvo em: {caminho_db} <br> Arquivos salvos em: {caminho_files}')
            elif sucesso_db:
                messages.warning(request,f'Backup completo com sucesso parcial! <br> Banco de dados salvo em: {caminho_db} <br> Erro ao salvar os arquivos')
            elif sucesso_files:
                messages.warning(request,f'Backup completo com sucesso parcial! <br> Arquivos salvos em: {caminho_files} <br> Erro ao salvar o banco de dados')
            else:
                messages.error(request, 'Erro ao fazer backup do banco de dados e dos arquivos!')

        elif fazer_backup_database:
            #executa so o backup do banco de dados
            sucesso, caminho = backup_database()
            if sucesso:
                messages.success(request, f'Backup do banco de dados realizado com sucesso em: {caminho}')
            else:
                messages.error(request, 'Erro ao fazer backup do banco de dados!')

        elif fazer_backup_files:
            #executa so o backup dos arquivos.
            sucesso, caminho = backup_site_files()
            if sucesso:
                messages.success(request, f'Backup dos arquivos realizado com sucesso em: {caminho}')
            else:
                messages.error(request, 'Erro ao fazer backup dos arquivos!')
        else:
            #nenhum selecionado
            messages.warning(request, 'Nenhum tipo de backup selecionado!')

        # Redireciona de volta para a página de backup (agora com as mensagens)
        return redirect('backup_page')


    # Se a requisição não for POST, renderiza a página normalmente
    return render(request, 'gerenciamento/backup_page.html')



