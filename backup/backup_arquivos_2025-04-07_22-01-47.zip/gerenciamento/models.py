﻿from django.db import models
from django.apps import apps
from django.utils import timezone

class Tiposstatus(models.Model): #MODIFICADO O NOME DA CLASSE.
    status = models.CharField(max_length=50)

    def __str__(self):
        return self.status
    class Meta:
       db_table = 'tipos_status' #COLOCADO O NOME CORRETO DA TABELA



class Membro(models.Model):
    chave = models.AutoField(db_column='Chave', primary_key=True)
    nome = models.CharField(max_length=100)
    apelido = models.TextField(blank=True, null=True)
    cpf = models.TextField(blank=True, null=True)
    nascimento = models.DateField()
    genero = models.CharField(max_length=10)
    cep = models.TextField(blank=True, null=True)
    pais = models.TextField(blank=True, null=True)
    estado = models.TextField(blank=True, null=True)
    cidade = models.TextField(blank=True, null=True)
    bairro_distrito = models.TextField(blank=True, null=True)
    rua = models.TextField(blank=True, null=True)
    numero_casa = models.TextField(blank=True, null=True)
    complemento = models.TextField(db_column='Complemento', blank=True, null=True)
    telefone = models.TextField(blank=True, null=True)
    data_entrada = models.TextField(blank=True, null=True)
    status = models.ForeignKey(Tiposstatus, on_delete=models.PROTECT)
    rg = models.TextField(blank=True, null=True)
    naturalidade = models.TextField(blank=True, null=True)
    nome_pai = models.TextField(blank=True, null=True)
    nome_mae = models.TextField(blank=True, null=True)
    estado_civil = models.TextField(blank=True, null=True)
    profissao = models.TextField(blank=True, null=True)
    escolaridade = models.TextField(blank=True, null=True)
    conjuge = models.TextField(blank=True, null=True)
    data_casamento = models.TextField(blank=True, null=True)
   
    def __str__(self):
        return self.nome
    
    class Meta:
        db_table = 'membros' # NOME CORRETO DA TABELA

class Cargos(models.Model):
    cargo = models.TextField(unique=True, blank=True, null=True)

    class Meta:
        db_table = 'cargos' # NOME CORRETO DA TABELA

class Contatos(models.Model):
    membro = models.ForeignKey(Membro, on_delete=models.CASCADE, blank=True, null=True)
    telefone_principal = models.TextField(blank=True, null=True)
    telefone_alternativo = models.TextField(blank=True, null=True)
    whatsapp = models.TextField(blank=True, null=True)
    email = models.TextField(blank=True, null=True)
    contato_emergencia_nome = models.TextField(blank=True, null=True)
    contato_emergencia_telefone = models.TextField(blank=True, null=True)
    contato_emergencia_parentesco = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'contatos' # NOME CORRETO DA TABELA

class Eventos(models.Model):
    nome_evento = models.TextField(blank=True, null=True)
    descricao = models.TextField(blank=True, null=True)
    data = models.DateField(blank=True, null=True)
    horario = models.TimeField(blank=True, null=True)

    class Meta:
        db_table = 'eventos' # NOME CORRETO DA TABELA

class EventosParticipacao(models.Model):
    evento = models.ForeignKey(Eventos, on_delete=models.CASCADE, blank=True, null=True)
    membro = models.ForeignKey(Membro, on_delete=models.CASCADE, blank=True, null=True)
    status_presenca = models.TextField(blank=True, null=True)
    justificativa = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'eventos_participacao' # NOME CORRETO DA TABELA

class Familia(models.Model):
    membro = models.ForeignKey(Membro, on_delete=models.CASCADE, to_field='chave', blank=True, null=True)
    conjuge = models.TextField(blank=True, null=True)
    data_casamento = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'familia' # NOME CORRETO DA TABELA

class Filhos(models.Model):
    membro = models.ForeignKey(Membro, on_delete=models.CASCADE, blank=True, null=True)
    nome = models.TextField(blank=True, null=True)
    data_nascimento = models.TextField(blank=True, null=True)
    frequenta_igreja = models.BooleanField(blank=True, null=True)

    class Meta:
        db_table = 'filhos' # NOME CORRETO DA TABELA

class Igrejas(models.Model):
    nome = models.TextField(blank=True, null=True)
    tipo = models.TextField(blank=True, null=True)
    endereco = models.TextField(blank=True, null=True)
    telefone = models.TextField(blank=True, null=True)
    email = models.TextField(blank=True, null=True)
    cnpj = models.TextField(blank=True, null=True)
    logo = models.BinaryField(blank=True, null=True)
    igreja_pai = models.ForeignKey('self', on_delete=models.CASCADE, blank=True, null=True)

    class Meta:
        db_table = 'igrejas' # NOME CORRETO DA TABELA

class InfoEclesiastica(models.Model):
    membro = models.ForeignKey(Membro, on_delete=models.CASCADE, to_field='chave', blank=True, null=True)
    data_conversao = models.TextField(blank=True, null=True)
    data_batismo = models.TextField(blank=True, null=True)
    igreja_origem = models.TextField(blank=True, null=True)
    data_admissao = models.TextField(blank=True, null=True)
    forma_admissao = models.TextField(blank=True, null=True)
    ministerios = models.TextField(blank=True, null=True)
    dons_talentos = models.TextField(blank=True, null=True)
    tipo_membro = models.TextField(blank=True, null=True)
    cargo = models.TextField(blank=True, null=True)
    disponibilidade = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'info_eclesiastica' # NOME CORRETO DA TABELA

class MembrosCargos(models.Model):
    membro = models.ForeignKey(Membro, on_delete=models.CASCADE, blank=True, null=True)
    cargo = models.ForeignKey(Cargos, on_delete=models.CASCADE, blank=True, null=True)

    class Meta:
        db_table = 'membros_cargos' # NOME CORRETO DA TABELA

class Observacoes(models.Model):
    membro = models.ForeignKey(Membro, on_delete=models.CASCADE, to_field='chave', blank=True, null=True)
    necessidades_especiais = models.TextField(blank=True, null=True)
    observacoes_medicas = models.TextField(blank=True, null=True)
    alergias = models.TextField(blank=True, null=True)
    observacoes_gerais = models.TextField(blank=True, null=True)
    caminho_foto = models.TextField(blank=True, null=True)
    caminho_documentos = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'observacoes' # NOME CORRETO DA TABELA

class OutrosFamiliares(models.Model):
    membro = models.ForeignKey(Membro, on_delete=models.CASCADE, blank=True, null=True)
    nome = models.TextField(blank=True, null=True)
    parentesco = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'outros_familiares' # NOME CORRETO DA TABELA

class StatusHistorico(models.Model):
    membro = models.ForeignKey(Membro, on_delete=models.CASCADE)
    status_anterior = models.ForeignKey(Tiposstatus, related_name='status_anterior', on_delete=models.CASCADE)
    novo_status = models.ForeignKey(Tiposstatus, related_name='novo_status', on_delete=models.CASCADE)
    data_mudanca = models.DateTimeField(auto_now_add=True)

    class Meta:
        #managed = False #DEIXE ASSIM! O DJANGO NAO IRA GERENCIAR ELA.
        db_table = 'status_historico' # MANTEM ASSIM
        #app_label = 'gerenciamento' #ADICIONE ESTA LINHA, INDICANDO QUAL A APP.




class Usuarios(models.Model):
    username = models.TextField(unique=True)
    password = models.TextField()

    class Meta:
        db_table = 'usuarios' # NOME CORRETO DA TABELA
