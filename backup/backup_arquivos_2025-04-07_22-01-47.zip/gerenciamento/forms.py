from django import forms
from .models import Membro, Tiposstatus #importante importar o `Tiposstatus`.

class MembroForm(forms.ModelForm):
    genero = forms.ChoiceField(
        choices=[
            ('M', 'Masculino'),
            ('F', 'Feminino'),
        ],
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    estado_civil = forms.ChoiceField(
        choices=[
            ('Solteiro', 'Solteiro'),
            ('Casado', 'Casado'),
            ('Divorciado', 'Divorciado'),
            ('Amasiado', 'Amasiado'),
            ('Viuvo', 'Viuvo')
        ],
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    escolaridade = forms.ChoiceField(
        choices=[
            ('Ensino Fundamental Incompleto', 'Ensino Fundamental Incompleto'),
            ('Ensino Fundamental Completo', 'Ensino Fundamental Completo'),
            ('Ensino Médio Incompleto', 'Ensino Médio Incompleto'),
            ('Ensino Médio Completo', 'Ensino Médio Completo'),
            ('Ensino Superior Incompleto', 'Ensino Superior Incompleto'),
            ('Ensino Superior Completo', 'Ensino Superior Completo'),
            ('Pós-graduação', 'Pós-graduação'),
            ('Mestrado', 'Mestrado'),
            ('Sem Escolaridade', 'Sem Escolaridade'),
            ('Doutorado', 'Doutorado')
        ],
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    status = forms.ModelChoiceField(
        queryset=Tiposstatus.objects.all(), # Busca todos os objetos do model.
        widget=forms.Select(attrs={'class': 'form-control'}),
        empty_label="Selecione o status" # opcional, para ter uma opção vazia no começo.
    )
    class Meta:
        model = Membro
        #fields = '__all__' # Substituido para mostrar so os campos que eu quero.
        fields = [
            'nome', 'apelido', 'cpf', 'rg', 'naturalidade', 'nascimento', 'genero',
            'estado_civil', 'profissao', 'escolaridade', 'nome_pai', 'nome_mae',
            'cep', 'pais', 'estado', 'cidade', 'bairro_distrito', 'rua',
            'numero_casa', 'complemento', 'telefone', 'data_entrada', 'status',
            'conjuge', 'data_casamento'
        ]
        
        widgets = {
            'nome': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 100}),
            'apelido': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 50}),
            'cpf': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 14}),  # Máscara será adicionada no HTML
            'rg': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 20}),
            'naturalidade': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 50}),
            'nascimento': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            #'genero': forms.Select(attrs={'class': 'form-control'}), # substituido por cima
            #'estado_civil': forms.Select(attrs={'class': 'form-control'}), # substituido por cima
            'profissao': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 50}),
            #'escolaridade': forms.Select(attrs={'class': 'form-control'}), #substituido por cima
            'nome_pai': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 100}),
            'nome_mae': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 100}),
            'cep': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 9}),
            'pais': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 50}),
            'estado': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 50}),
            'cidade': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 50}),
            'bairro_distrito': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 50}),
            'rua': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 100}),
            'numero_casa': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 10}),
            'complemento': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 100}),
            'telefone': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 15}),
            'data_entrada': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 10}),
            #'status': forms.Select(attrs={'class': 'form-control'}), #removido, substituido por cima.
            'conjuge': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 100}),
            'data_casamento': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 10}),
        }
