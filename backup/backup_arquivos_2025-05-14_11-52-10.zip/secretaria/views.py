# c:\Gereigreja\secretaria\views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Membro, Tiposstatus
from .forms import MembroForm
from django.http import HttpResponse, Http404
from datetime import datetime
from django.conf import settings
import os
import shutil
import logging
import zipfile
from django.db.models import Count, Q
import json
# Import timedelta para cálculos de data
from django.contrib.auth.decorators import login_required, user_passes_test
from configuracao.models import PerfilUsuario, Organizacao, Igreja # Adicionado Igreja
from django.core.exceptions import PermissionDenied
from datetime import datetime, date # Importe 'date' aqui também
from django.db.models import Count, Q, F, Value, Case, When, BooleanField # Adicione F, Value, Case, When, BooleanField
from django.urls import reverse_lazy # Para login_url

# --- IMPORTAR UTILS DE PERMISSÃO PARA secretaria ---
from .utils import (
    has_membro_view_permission,
    has_membro_edit_permission,
    get_allowed_churches_for_membros,
    is_admin_org # Importar is_admin_org se for usar no form
) # Adicionado timedelta
from django.db.models.functions import Extract # Adicione esta linha para Extract


# Configura o logger (mantido como estava)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler = logging.FileHandler('backup_log.txt') # Considere um nome de arquivo mais específico ou um caminho absoluto
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

# --- Função auxiliar para obter organização (evita repetição) ---
def get_organizacao_or_error(request):
    """
    Obtém a organização do usuário logado.
    Levanta PermissionDenied se não autenticado, superuser, ou erro de perfil.
    Levanta Http404 se o perfil não tem organização associada.
    Retorna o objeto Organizacao em caso de sucesso.
    """
    if not request.user.is_authenticated:
        raise PermissionDenied("Usuário não autenticado.")
    try:
        # Superusuários não têm uma organização padrão nesta lógica
        if request.user.is_superuser:
             messages.info(request, "Superusuários devem usar o painel Admin para secretaria global.")
             raise PermissionDenied("Superusuário não acessa esta área.")

        perfil = request.user.perfil
        organizacao = perfil.organizacao
        if not organizacao:
            # Situação inesperada para um admin logado
            messages.error(request, "Seu usuário não está associado a nenhuma organização.")
            raise Http404("Organização não encontrada para o usuário.")
        return organizacao
    except PerfilUsuario.DoesNotExist:
        messages.error(request, "Perfil de usuário não encontrado. Contate o suporte.")
        raise PermissionDenied("Perfil de usuário não encontrado.")
    except Exception as e:
         logger.exception(f"Erro inesperado ao obter organização para usuário {request.user.username}")
         messages.error(request, f"Erro interno ao obter organização: {e}")
         raise PermissionDenied("Erro interno ao obter organização.")
# --- Fim função auxiliar ---


@login_required
def index(request):
    if request.user.is_superuser:
        return redirect('admin:index')
    try:
        organizacao = get_organizacao_or_error(request)

        can_view = has_membro_view_permission(request.user)
        can_edit = has_membro_edit_permission(request.user)

        total_membros_ativos_count = 0
        novos_membros_ultimo_mes_count = 0
        # proximo_evento_info = "Nenhum evento próximo." # Placeholder

        if can_view:
            allowed_churches = get_allowed_churches_for_membros(request.user)
            if allowed_churches.exists() or is_admin_org(request.user): # Admin Org pode ver mesmo sem igrejas específicas se a lógica de get_allowed_churches_for_membros retornar todas
                # Se for Admin Org, allowed_churches já deve conter todas as igrejas da organização
                # ou ser um queryset que abrange todas elas.
                membros_visiveis = Membro.objects.filter(igreja__in=allowed_churches)

                total_membros_ativos_count = membros_visiveis.filter(
                    status__considerar_ativo_relatorios=True
                ).count()

                # Para 'novos_membros_ultimo_mes', assumimos um campo 'data_cadastro' no modelo Membro.
                # Ajuste o nome do campo 'data_cadastro' se for diferente no seu modelo.
                from datetime import timedelta # Já importado no topo do arquivo
                um_mes_atras = date.today() - timedelta(days=30)
                novos_membros_ultimo_mes_count = membros_visiveis.filter(
                    data_entrada__gte=um_mes_atras # CORRIGIDO: Usando 'data_entrada'
                ).count()
        print(f"DEBUG VIEW: can_view = {can_view}")
        print(f"DEBUG VIEW: novos_membros_ultimo_mes_count = {novos_membros_ultimo_mes_count} (Tipo: {type(novos_membros_ultimo_mes_count)})")
        print(f"DEBUG VIEW: total_membros_ativos_count = {total_membros_ativos_count} (Tipo: {type(total_membros_ativos_count)})")
        
        context = {
            'organizacao': organizacao,
            'user': request.user,
            'titulo_pagina': 'Página Inicial',
            'can_view_membros': can_view,
            'can_edit_membros': can_edit,
            'total_membros_ativos': total_membros_ativos_count,
            'novos_membros_ultimo_mes': novos_membros_ultimo_mes_count,
            'proximo_evento': "Nenhum evento próximo." # Placeholder
        }
        return render(request, 'secretaria/index.html', context)
    except (PermissionDenied, Http404):
         return redirect('login')


@login_required
def dashboard(request):
    organizacao = get_organizacao_or_error(request)

    # Verificar permissão de visualização de membros antes de prosseguir
    if not has_membro_view_permission(request.user):
        messages.warning(request, "Você não tem permissão para visualizar os dados do dashboard.")
        context = {
            'organizacao': organizacao,
            'titulo_pagina': 'Dashboard da Organização',
            'status_data_json': json.dumps([]),
            'genero_data_json': json.dumps([]),
            'faixa_etaria_data_json': json.dumps([]),
            'total_membros_dashboard': 0,
            'aniversariantes_proximos': [],
            'permissao_negada': True # Flag para o template, se necessário
        }
        return render(request, 'dashboard.html', context)

    allowed_churches = get_allowed_churches_for_membros(request.user)

    if not allowed_churches.exists() and not is_admin_org(request.user):
        # Se não for Admin da Org e não tiver igrejas permitidas, não há dados para mostrar
        messages.info(request, "Nenhuma igreja associada para visualização de dados no dashboard.")
        context = {
            'organizacao': organizacao,
            'titulo_pagina': 'Dashboard da Organização',
            'status_data_json': json.dumps([]),
            'genero_data_json': json.dumps([]),
            'faixa_etaria_data_json': json.dumps([]),
            'total_membros_dashboard': 0,
            'aniversariantes_proximos': [],
        }
        return render(request, 'dashboard.html', context)

    membros_para_relatorios = Membro.objects.filter(
        igreja__in=allowed_churches,  # ALTERAÇÃO PRINCIPAL: Filtra pelas igrejas permitidas
        status__considerar_ativo_relatorios=True
    )

    # 1. Contagem por Status
    status_data = membros_para_relatorios.values(
        'status__status'
    ).annotate(
        total=Count('chave')
    ).order_by('status__status')
    status_data_list = [{'status': item['status__status'], 'total': item['total']} for item in status_data]
    logger.info(f"Dashboard - Status Data (Filtrado): {status_data_list}")

    # 2. Contagem por Gênero
    genero_data = membros_para_relatorios.values('genero').annotate(
        total=Count('chave')
    )
    genero_map = {'F': 'Feminino', 'M': 'Masculino', '': 'Não Informado', None: 'Não Informado'}
    aggregated_genero = {}
    for item in genero_data:
        genero_display = genero_map.get(item['genero'], 'Não Informado')
        aggregated_genero[genero_display] = aggregated_genero.get(genero_display, 0) + item['total']
    genero_data_normalized = [{'genero': key, 'total': value} for key, value in aggregated_genero.items()]
    logger.info(f"Dashboard - Gênero Data Normalized (Filtrado e Agregado): {genero_data_normalized}")

    # 3. Contagem por Faixa Etária
    membros_com_nascimento = membros_para_relatorios.filter(
        nascimento__isnull=False
    ).values_list('nascimento', flat=True)
    idades = []
    hoje_data = date.today() # Renomeado para evitar conflito com datetime.date
    for nascimento in membros_com_nascimento:
        if nascimento:
            try:
                idade = hoje_data.year - nascimento.year - ((hoje_data.month, hoje_data.day) < (nascimento.month, nascimento.day))
                idades.append(idade)
            except AttributeError:
                logger.warning(f"Valor inesperado encontrado para data de nascimento ao calcular idade: {nascimento}")
        else:
            logger.warning("Valor None encontrado para nascimento mesmo após filtro isnull=False.")

    faixas = {'Menor de 18': 0, '18-30': 0, '31-50': 0, 'Mais de 50': 0}
    for idade_val in idades: # Renomeado para evitar conflito
        if idade_val < 18:
            faixas['Menor de 18'] += 1
        elif 18 <= idade_val <= 30:
            faixas['18-30'] += 1
        elif 31 <= idade_val <= 50:
            faixas['31-50'] += 1
        else:
            faixas['Mais de 50'] += 1
    faixa_etaria_data = [{'faixa_etaria': k, 'total': v} for k, v in faixas.items()]
    logger.info(f"Dashboard - Faixa Etária Data (Filtrado): {faixa_etaria_data}")

    # 4. Total de Membros para o Dashboard
    total_membros_dashboard = membros_para_relatorios.count()
    logger.info(f"Dashboard - Total de Membros (Filtrado): {total_membros_dashboard}")

    # 5. Próximos Aniversariantes
    mes_atual = hoje_data.month
    dia_atual = hoje_data.day
    aniversariantes_qs = membros_para_relatorios.filter(nascimento__isnull=False).annotate(
        nascimento_month=Extract('nascimento', 'month'),
        nascimento_day=Extract('nascimento', 'day'),
        passed_this_year=Case(
            When(nascimento_month__lt=mes_atual, then=Value(True)),
            When(nascimento_month=mes_atual, nascimento_day__lt=dia_atual, then=Value(True)),
            default=Value(False),
            output_field=BooleanField()
        )
    ).order_by('passed_this_year', 'nascimento_month', 'nascimento_day')
    limite_aniversariantes = 10
    aniversariantes_proximos = list(aniversariantes_qs[:limite_aniversariantes])
    logger.info(f"Dashboard - Próximos Aniversariantes (até {limite_aniversariantes}): {[m.nome for m in aniversariantes_proximos]}")

    context = {
        'status_data_json': json.dumps(status_data_list),
        'genero_data_json': json.dumps(genero_data_normalized),
        'faixa_etaria_data_json': json.dumps(faixa_etaria_data),
        'total_membros_dashboard': total_membros_dashboard,
        'organizacao': organizacao,
        'aniversariantes_proximos': aniversariantes_proximos,
        'titulo_pagina': 'Dashboard da Organização' # Adicionado título
    }
    return render(request, 'dashboard.html', context)


@login_required
@user_passes_test(has_membro_view_permission, login_url=reverse_lazy('login'), redirect_field_name=None)
def lista_membros(request):
    organizacao = get_organizacao_or_error(request)
    allowed_churches = get_allowed_churches_for_membros(request.user)

    # Filtra membros pelas igrejas permitidas
    membros_queryset = Membro.objects.filter(
        igreja__in=allowed_churches
    ).select_related('igreja', 'status').order_by('nome')

    query = request.GET.get('q')
    if query:
        membros_queryset = membros_queryset.filter(
            Q(nome__icontains=query) | Q(apelido__icontains=query)
        )

    can_edit = has_membro_edit_permission(request.user)

    context = {
        'membros': membros_queryset,
        'organizacao': organizacao,
        'query': query,
        'can_edit_membros': can_edit,
        'titulo_pagina': 'Lista de Membros'
    }
    return render(request, 'secretaria/lista_membros.html', context)


@login_required
@user_passes_test(has_membro_edit_permission, login_url=reverse_lazy('login'), redirect_field_name=None)
def editar_membro(request, membro_id):
    organizacao = get_organizacao_or_error(request)
    allowed_churches = get_allowed_churches_for_membros(request.user)
    membro = get_object_or_404(Membro, pk=membro_id, igreja__in=allowed_churches)

    if request.method == 'POST':
        form = MembroForm(request.POST, instance=membro, organizacao=organizacao, user=request.user, allowed_churches=allowed_churches)
        print(f"DEBUG POST - request.POST: {request.POST}") # Veja os dados brutos do POST
        if form.is_valid():
            print(f"DEBUG POST - form.cleaned_data: {form.cleaned_data}") # Veja os dados limpos
            nascimento_do_form = form.cleaned_data.get('nascimento')
            print(f"DEBUG POST - Nascimento do form.cleaned_data: {nascimento_do_form}, Tipo: {type(nascimento_do_form)}")
            try:
                membro_editado = form.save(commit=False)
                print(f"DEBUG POST - membro_editado.nascimento ANTES do save: {membro_editado.nascimento}, Tipo: {type(membro_editado.nascimento)}")
                if not is_admin_org(request.user) and membro_editado.igreja not in allowed_churches:
                    messages.error(request, "Erro: Igreja selecionada inválida para sua permissão.")
                else:
                    membro_editado.save()
                    messages.success(request, f'Membro "{membro_editado.nome}" atualizado com sucesso!')
                    return redirect('lista_membros')
            except Exception as e:
                print(f"DEBUG POST - Exceção ao salvar: {e}")

                logger.exception(f"Erro ao salvar edição do membro {membro_id} para organização {organizacao.id}")
                messages.error(request, f"Ocorreu um erro ao salvar as alterações: {e}")
        else:
            # Adicionar este print para depuração quando o formulário é carregado (GET)
            print(f"DEBUG POST - Form inválido. Erros: {form.errors.as_json()}")

            messages.error(request, "Erro ao atualizar membro. Verifique os campos.")
    else:
        form = MembroForm(instance=membro, organizacao=organizacao, user=request.user, allowed_churches=allowed_churches)
        # Print para quando o formulário é carregado (GET)
        print(f"DEBUG GET - Editando Membro ID: {membro.pk}")
        print(f"DEBUG GET - Valor de membro.nascimento no BD: {membro.nascimento}")
        print(f"DEBUG GET - Tipo de membro.nascimento no BD: {type(membro.nascimento)}")

    context = {
        'form': form,
        'membro_id': membro_id,
        'organizacao': organizacao,
        'titulo_pagina': f'Editar Membro: {membro.nome}'
    }
    return render(request, 'secretaria/editar_membro.html', context)


@login_required
@user_passes_test(has_membro_edit_permission, login_url=reverse_lazy('login'), redirect_field_name=None)
def criar_membro(request):
    organizacao = get_organizacao_or_error(request)
    allowed_churches = get_allowed_churches_for_membros(request.user)

    if not is_admin_org(request.user) and not allowed_churches.exists():
        messages.error(request, "Você não tem permissão para adicionar membros ou não está associado a nenhuma igreja específica.")
        return redirect('lista_membros')

    if request.method == 'POST':
        form = MembroForm(request.POST, organizacao=organizacao, user=request.user, allowed_churches=allowed_churches)
        if form.is_valid():
            print(f"DEBUG POST - form.cleaned_data: {form.cleaned_data}")
            nascimento_do_form = form.cleaned_data.get('nascimento')
            print(f"DEBUG POST - Nascimento do form.cleaned_data: {nascimento_do_form}, Tipo: {type(nascimento_do_form)}")

            try:
                membro_editado = form.save(commit=False)

                novo_membro = form.save(commit=False)
                if not is_admin_org(request.user) and novo_membro.igreja not in allowed_churches:
                    messages.error(request, "Erro: Igreja selecionada inválida para sua permissão.")
                else:
                    novo_membro.save()
                    messages.success(request, f'Membro "{novo_membro.nome}" cadastrado com sucesso!')
                    return redirect('lista_membros')
            except Exception as e:
                logger.exception(f"Erro ao salvar novo membro para organização {organizacao.id}")
                messages.error(request, f"Ocorreu um erro ao salvar o membro: {e}")
        else:
             messages.error(request, "Erro ao cadastrar membro. Verifique os campos.")
    else:
        form = MembroForm(organizacao=organizacao, user=request.user, allowed_churches=allowed_churches)

    context = {
        'form': form,
        'organizacao': organizacao,
        'titulo_pagina': 'Cadastrar Novo Membro'
    }
    return render(request, 'secretaria/criar_membro.html', context)


# --- Views de Backup (Restritas a Superusuários) ---
@login_required
@user_passes_test(lambda u: u.is_superuser, login_url='/admin/login/') # login_url pode ser ajustado se necessário
def backup_database_view(request): # Adicionado 'request'
    data_hora_atual = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    backup_dir = os.path.join(settings.BASE_DIR, 'backup')
    os.makedirs(backup_dir, exist_ok=True)
    backup_file = f"backup_banco_{data_hora_atual}.sqlite3"
    backup_path = os.path.join(backup_dir, backup_file)
    db_path = settings.DATABASES['default']['NAME']
    try:
        shutil.copy2(db_path, backup_path)
        logger.info(f"Backup do banco de dados realizado com sucesso em: {backup_path}")
        return True, backup_path
    except Exception as e:
        logger.error(f"Erro ao realizar backup do banco de dados: {e}")
        return False, None

@login_required
@user_passes_test(lambda u: u.is_superuser, login_url='/admin/login/') # login_url pode ser ajustado
def backup_site_files_view(request): # Adicionado 'request'
    data_hora_atual = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    backup_dir = os.path.join(settings.BASE_DIR, 'backup')
    os.makedirs(backup_dir, exist_ok=True)
    backup_file = f"backup_arquivos_{data_hora_atual}.zip"
    backup_path = os.path.join(backup_dir, backup_file)
    site_path = settings.BASE_DIR
    folders_to_ignore = [
        os.path.join(settings.BASE_DIR, 'backup'),
        os.path.join(settings.BASE_DIR, 'static'), # Se staticfiles_dirs estiver configurado, pode ser redundante
        os.path.join(settings.BASE_DIR, 'staticfiles'), # Diretório do collectstatic
        os.path.join(settings.BASE_DIR, 'media'),
        os.path.join(settings.BASE_DIR, '__pycache__'),
        os.path.join(settings.BASE_DIR, '.venv'),
        os.path.join(settings.BASE_DIR, 'venv'),
        os.path.join(settings.BASE_DIR, '.git'),
        # Adicionar outros diretórios/arquivos se necessário
    ]
    try:
        logger.info(f"Iniciando backup dos arquivos do site.")
        with zipfile.ZipFile(backup_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(site_path):
                # Ignorar diretórios
                dirs[:] = [d for d in dirs if os.path.join(root, d) not in folders_to_ignore and not d.startswith('.') and d != '__pycache__']

                if any(root.startswith(folder) for folder in folders_to_ignore):
                    continue

                for file in files:
                    if file.startswith('.'):
                        continue
                    file_path = os.path.join(root, file)
                    relative_path = os.path.relpath(file_path, site_path)
                    zipf.write(file_path, arcname=relative_path)
        logger.info(f"Backup dos arquivos do site realizado com sucesso em: {backup_path}")
        return True, backup_path
    except Exception as e:
        logger.exception(f"Erro ao realizar backup dos arquivos do site")
        return False, None

@login_required
@user_passes_test(lambda u: u.is_superuser, login_url='/admin/login/')
def backup_page(request):
    if request.method == 'POST':
        fazer_backup_database = 'backup_database' in request.POST
        fazer_backup_files = 'backup_files' in request.POST
        storage = messages.get_messages(request)
        storage.used = True
        db_success, file_success = None, None
        db_path, file_path = None, None

        if fazer_backup_database:
            db_success, db_path = backup_database_view(request) # Passado 'request'
        if fazer_backup_files:
            file_success, file_path = backup_site_files_view(request) # Passado 'request'

        if fazer_backup_database and fazer_backup_files:
            if db_success and file_success:
                messages.success(request, f'Backup Completo realizado com sucesso! <br>Banco: {db_path} <br> Arquivos: {file_path}')
            elif db_success:
                messages.warning(request, f'Backup parcial! <br>Banco: {db_path} <br> Erro nos arquivos.')
            elif file_success:
                 messages.warning(request, f'Backup parcial! <br>Arquivos: {file_path} <br> Erro no banco.')
            else:
                messages.error(request, 'Erro ao fazer backup do banco de dados e dos arquivos!')
        elif fazer_backup_database:
            if db_success:
                messages.success(request, f'Backup do banco de dados realizado com sucesso: {db_path}')
            else:
                messages.error(request, 'Erro ao fazer backup do banco de dados!')
        elif fazer_backup_files:
            if file_success:
                messages.success(request, f'Backup dos arquivos realizado com sucesso: {file_path}')
            else:
                messages.error(request, 'Erro ao fazer backup dos arquivos!')
        else:
            messages.warning(request, 'Nenhum tipo de backup selecionado!')
        return redirect('backup_page')
    return render(request, 'secretaria/backup_page.html')

# --- NOVA VIEW PARA ALTERNAR STATUS DO MEMBRO ---
@login_required
@user_passes_test(has_membro_edit_permission, login_url=reverse_lazy('login'), redirect_field_name=None)
def alternar_status_membro(request, membro_id):
    organizacao = get_organizacao_or_error(request)
    allowed_churches = get_allowed_churches_for_membros(request.user)
    membro = get_object_or_404(Membro, pk=membro_id, igreja__in=allowed_churches)

    # Defina os nomes dos seus Tiposstatus padrão para ativo e inativo
    # Estes nomes devem corresponder exatamente aos cadastrados no seu modelo Tiposstatus
    NOME_STATUS_ATIVO_PADRAO = "MEMBRO ATIVO"
    NOME_STATUS_INATIVO_PADRAO = "MEMBRO INATIVO"

    if request.method == 'POST':
        try:
            status_ativo_padrao = Tiposstatus.objects.get(status=NOME_STATUS_ATIVO_PADRAO)
            status_inativo_padrao = Tiposstatus.objects.get(status=NOME_STATUS_INATIVO_PADRAO)

            acao = ""
            if membro.status and membro.status.considerar_ativo_relatorios:
                # Se está ativo para relatórios, inativa
                membro.status = status_inativo_padrao
                acao = "inativado (para relatórios)"
            else:
                # Se está inativo para relatórios (ou sem status), ativa
                membro.status = status_ativo_padrao
                acao = "ativado (para relatórios)"

            membro.save(update_fields=['status'])
            messages.success(request, f'Membro "{membro.nome}" foi {acao} com sucesso.')

        except Tiposstatus.DoesNotExist:
            messages.error(request, f"Erro: Os status '{NOME_STATUS_ATIVO_PADRAO}' ou '{NOME_STATUS_INATIVO_PADRAO}' não foram encontrados. Verifique o cadastro de Tipos de Status.")
        except Exception as e:
            logger.exception(f"Erro ao alternar status do membro {membro_id} para organização {organizacao.id}")
            messages.error(request, f"Ocorreu um erro ao alternar o status do membro: {e}")
        return redirect('lista_membros') # Sempre redireciona para a lista
    else:
        # GET request não é permitido para esta ação
        messages.error(request, "Ação inválida.")
        return redirect('lista_membros')
# --- FIM NOVA VIEW ---