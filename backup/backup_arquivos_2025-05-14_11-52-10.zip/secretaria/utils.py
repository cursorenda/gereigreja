# c:\Gereigreja\secretaria\utils.py
from django.contrib.auth.models import User, Group
from configuracao.models import Igreja, PerfilUsuario # Importar PerfilUsuario e Igreja

# --- Funções de Verificação de Grupo (Reutilizáveis) ---

def _user_in_group(user, group_name):
    """Verifica se o usuário pertence a um grupo específico."""
    if not user.is_authenticated:
        return False
    # Otimização: Verificar se o usuário já tem os grupos pré-carregados
    if hasattr(user, '_prefetched_objects_cache') and 'groups' in user._prefetched_objects_cache:
        return any(group.name == group_name for group in user.groups.all())
    # Fallback: Consultar o banco de dados
    return user.groups.filter(name=group_name).exists()

def is_admin_org(user):
    """Verifica se o usuário é Admin da Organização."""
    return _user_in_group(user, 'Admin Organizacao')

def is_secretario(user):
    """Verifica se o usuário é Secretário."""
    return _user_in_group(user, 'Secretario')

def is_lider_igreja(user):
    """Verifica se o usuário é Lider Igreja."""
    return _user_in_group(user, 'Lider Igreja')

def is_tesoureiro(user):
    """Verifica se o usuário é Tesoureiro."""
    return _user_in_group(user, 'Tesoureiro')

# --- Funções de Verificação de Permissão para secretaria de Membros ---

def has_membro_view_permission(user):
    """Verifica se o usuário tem permissão para VER dados de membros."""
    return is_admin_org(user) or is_secretario(user) or is_lider_igreja(user) or is_tesoureiro(user)

def has_membro_edit_permission(user):
    """Verifica se o usuário tem permissão para EDITAR/ADICIONAR/INATIVAR dados de membros."""
    return is_admin_org(user) or is_secretario(user)

# --- Função para Obter Igrejas Permitidas para secretaria de Membros ---

def get_allowed_churches_for_membros(user):
    """
    Retorna um QuerySet das Igrejas que o usuário tem permissão para acessar no contexto de membros.
    - Admin Org: Todas as igrejas da organização.
    - Secretário, Líder, Tesoureiro: Igrejas associadas no PerfilUsuario.
    - Outros: Nenhuma igreja.
    - Retorna QuerySet vazio se o usuário não tiver perfil/organização ou permissão de visualização.
    """
    if not user.is_authenticated or not hasattr(user, 'perfil') or not user.perfil.organizacao:
        return Igreja.objects.none()

    # Verifica se o usuário tem PELO MENOS permissão de visualização de membros
    if not has_membro_view_permission(user):
        return Igreja.objects.none()

    organizacao = user.perfil.organizacao

    if is_admin_org(user):
        # Admin Org tem acesso a todas as igrejas da organização
        return Igreja.objects.filter(organizacao=organizacao)
    elif is_secretario(user) or is_lider_igreja(user) or is_tesoureiro(user):
        # Secretário, Líder e Tesoureiro têm acesso às igrejas explicitamente permitidas no perfil
        # Garante que as igrejas retornadas pertencem à organização do usuário (segurança extra)
        return user.perfil.igrejas_permitidas.filter(organizacao=organizacao)
    else:
        # Outros usuários (que passaram no has_membro_view_permission mas não se encaixam acima?)
        # Por segurança, retorna vazio.
        return Igreja.objects.none()