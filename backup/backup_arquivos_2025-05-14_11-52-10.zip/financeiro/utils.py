# c:\Gereigreja\financeiro\utils.py
from functools import wraps
from django.core.exceptions import PermissionDenied
from django.shortcuts import redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.models import User, Group
from configuracao.models import Igreja, PerfilUsuario # Importar PerfilUsuario


# --- Funções de Verificação de Grupo ---

def _user_in_group(user, group_name):
    """Verifica se o usuário pertence a um grupo específico."""
    if not user.is_authenticated:
        return False
    # Otimização: Verificar se o usuário já tem os grupos pré-carregados
    if hasattr(user, '_prefetched_objects_cache') and 'groups' in user._prefetched_objects_cache:
        return any(group.name == group_name for group in user.groups.all())
    # Fallback: Consultar o banco de dados
    return user.groups.filter(name=group_name).exists()

def is_admin_org(user):
    """Verifica se o usuário é Admin da Organização."""
    return _user_in_group(user, 'Admin Organizacao')

def is_tesoureiro(user):
    """Verifica se o usuário é Tesoureiro."""
    # IMPORTANTE: Ajuste o nome do grupo se for diferente de 'Tesoureiro'
    return _user_in_group(user, 'Tesoureiro')

def is_lider_igreja(user):
    """Verifica se o usuário é Lider Igreja."""
    # IMPORTANTE: Ajuste o nome do grupo se for diferente de 'Lider Igreja'
    return _user_in_group(user, 'Lider Igreja')

# --- Funções de Verificação de Permissão Financeira ---

def has_finance_view_permission(user):
    """Verifica se o usuário tem permissão para VER dados financeiros."""
    return is_admin_org(user) or is_tesoureiro(user) or is_lider_igreja(user)

def has_finance_edit_permission(user):
    """Verifica se o usuário tem permissão para EDITAR/ADICIONAR/EXCLUIR dados financeiros."""
    # Lider Igreja NÃO tem permissão de edição por padrão aqui.
    return is_admin_org(user) or is_tesoureiro(user)

# --- Função para Obter Igrejas Permitidas ---

def get_allowed_churches_for_user(user):
    """
    Retorna um QuerySet das Igrejas que o usuário tem permissão para acessar financeiramente.
    - Admin Org: Todas as igrejas da organização.
    - Tesoureiro, Líder: Igrejas associadas no PerfilUsuario.
    - Outros: Nenhuma igreja.
    - Retorna QuerySet vazio se o usuário não tiver perfil/organização ou permissão de visualização.
    """
    if not user.is_authenticated or not hasattr(user, 'perfil') or not user.perfil.organizacao:
        return Igreja.objects.none() # Retorna queryset vazio por segurança

    # Verifica se o usuário tem PELO MENOS permissão de visualização financeira
    if not has_finance_view_permission(user):
        return Igreja.objects.none()

    organizacao = user.perfil.organizacao

    if is_admin_org(user):
        # Admin Org tem acesso a todas as igrejas da organização
        return Igreja.objects.filter(organizacao=organizacao)
    elif is_tesoureiro(user) or is_lider_igreja(user):
        # Tesoureiro e Líder têm acesso às igrejas explicitamente permitidas no perfil
        # Se nenhuma igreja for permitida, o M2M retorna um queryset vazio, o que é correto.
        # Garante que as igrejas retornadas pertencem à organização do usuário (segurança extra)
        return user.perfil.igrejas_permitidas.filter(organizacao=organizacao)
    else:
        # Outros usuários (que passaram no has_finance_view_permission mas não são Admin/Tesoureiro/Líder?)
        # Por segurança, retorna vazio. Ajuste se houver outros papéis com acesso.
        return Igreja.objects.none()

