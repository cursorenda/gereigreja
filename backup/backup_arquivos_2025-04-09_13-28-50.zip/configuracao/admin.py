# c:\Gereigreja\configuracao\admin.py
from django.contrib import admin
from .models import IgrejaConfiguracao

@admin.register(IgrejaConfiguracao) # Outra forma de registrar, equivalente a admin.site.register
class IgrejaConfiguracaoAdmin(admin.ModelAdmin):
    # --- Configurações da Lista (manter como estava ou ajustar) ---
    list_display = (
        'nome_igreja',
        'tipo_igreja',
        'igreja_superior',
        'cidade',
        'estado',
        'pastor_local',
        'telefone',
    )
    list_filter = ('tipo_igreja', 'estado', 'pais', 'igreja_superior')
    search_fields = ('nome_igreja', 'cidade', 'pastor_local', 'cnpj')

    # --- Configuração do Formulário de Edição/Adição ---
    fieldsets = (
        # Seção 1: Informações Principais
        ('Informações da Igreja', {
            'fields': (
                'nome_igreja', # Campo único na linha
                ('tipo_igreja', 'igreja_superior') # Campos lado a lado
            )
        }),
        # Seção 2: Endereço
        ('Endereço', {
            # 'classes': ('collapse',), # Descomente se quiser que a seção comece fechada
            'fields': (
                'cep', # Primeiro campo, sozinho na linha
                'rua', # Sozinho na linha
                ('numero', 'complemento'), # Lado a lado
                ('bairro', 'cidade'),      # Lado a lado
                ('estado', 'pais')         # Lado a lado
            ),
            # Nota: A funcionalidade de buscar endereço pelo CEP requer JavaScript adicional.
            # Isso apenas organiza os campos visualmente.
            'description': "Organização dos campos de endereço. A busca automática por CEP requer customização adicional."
        }),
        # Seção 3: Contatos e Documentos
        ('Contatos e Documentos', {
            'fields': (
                ('telefone', 'celular'), # Lado a lado
                ('email', 'cnpj'),       # Lado a lado
                'site'                   # Sozinho na linha
            )
        }),
        # Seção 4: Responsáveis
        ('Responsáveis', {
            'fields': (
                ('pastor_local', 'pastor_regional'), # Lado a lado
            )
        }),
        # Seção 5: Outras Configurações
        ('Outras Configurações', {
            'fields': (
                'moeda',
                'observacoes', # Textarea geralmente ocupa a linha toda
                ('logo1', 'logo2') # Lado a lado
            )
        }),
    )

# Não precisa mais do admin.site.register se usar o decorator @admin.register
# admin.site.register(IgrejaConfiguracao, IgrejaConfiguracaoAdmin)
