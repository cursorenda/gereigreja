# c:\Gereigreja\configuracao\models.py
from django.db import models

class IgrejaConfiguracao(models.Model):
    # --- Tipos de Igreja ---
    TIPO_IGREJA_CHOICES = [
        ('sede', 'Sede'),
        ('regional', 'Regional'),
        ('congregacao', 'Congregação'),
    ]
    tipo_igreja = models.CharField(
        max_length=20,
        choices=TIPO_IGREJA_CHOICES,
        default='congregacao',
        verbose_name="Tipo de Igreja"
    )

    # --- Relacionamento Hierárquico ---
    igreja_superior = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='igrejas_subordinadas',
        verbose_name="Igreja Superior (Sede/Regional)"
    )

    # --- Informações da Igreja ---
    nome_igreja = models.CharField(max_length=255, verbose_name="Nome da Igreja")
    # Removido: sub_sede e congregacao (a hierarquia é definida acima)

    # --- Endereço ---
    rua = models.CharField(max_length=255, blank=True, null=True, verbose_name="Rua")
    numero = models.CharField(max_length=10, blank=True, null=True, verbose_name="Número")
    complemento = models.CharField(max_length=100, blank=True, null=True, verbose_name="Complemento")
    bairro = models.CharField(max_length=255, blank=True, null=True, verbose_name="Bairro")
    cidade = models.CharField(max_length=100, blank=True, null=True, verbose_name="Cidade") # NOVO
    estado = models.CharField(max_length=50, blank=True, null=True, verbose_name="Estado")   # NOVO (Pode ser UF ou nome completo)
    pais = models.CharField(max_length=50, blank=True, null=True, default="Brasil", verbose_name="País") # NOVO
    cep = models.CharField(max_length=9, blank=True, null=True, verbose_name="CEP")
    # Removido: endereco

    # --- Contato e Documentos ---
    email = models.EmailField(blank=True, null=True, verbose_name="E-mail")
    cnpj = models.CharField(max_length=18, blank=True, null=True, verbose_name="CNPJ")
    telefone = models.CharField(max_length=20, blank=True, null=True, verbose_name="Telefone")
    celular = models.CharField(max_length=20, blank=True, null=True, verbose_name="Celular")
    site = models.URLField(blank=True, null=True, verbose_name="Site")

    # --- Responsáveis ---
    pastor_local = models.CharField(max_length=255, blank=True, null=True, verbose_name="Pastor Local / Responsável")
    pastor_regional = models.CharField(max_length=255, blank=True, null=True, verbose_name="Pastor Regional") # Pode ser obtido da igreja_superior se for Regional

    # --- Outras Configurações ---
    moeda = models.CharField(max_length=3, default="BRL", verbose_name="Moeda")
    observacoes = models.TextField(blank=True, null=True, verbose_name="Observações")
    logo1 = models.ImageField(upload_to='logos/', blank=True, null=True, verbose_name="Logo 1")
    logo2 = models.ImageField(upload_to='logos/', blank=True, null=True, verbose_name="Logo 2")

    def __str__(self):
        return f"{self.nome_igreja} ({self.get_tipo_igreja_display()})"

    class Meta:
        verbose_name = "Configuração da Igreja"
        verbose_name_plural = "Configurações das Igrejas"
        ordering = ['nome_igreja']
        