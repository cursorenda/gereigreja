from django.shortcuts import render, redirect
from .forms import IgrejaConfiguracaoForm
from .models import IgrejaConfiguracao

def configuracao_view(request):
    configuracao = IgrejaConfiguracao.objects.first()
    if request.method == 'POST':
        form = IgrejaConfiguracaoForm(request.POST, request.FILES, instance=configuracao) # Adicionado request.FILES
        if form.is_valid():
            form.save()
            return redirect('configuracao:configuracao') # Modificado
    else:
        form = IgrejaConfiguracaoForm(instance=configuracao)
    return render(request, 'configuracao/configuracao.html', {'form': form})
