from django.urls import path
from . import views

app_name = 'configuracao'  # Adicionado

urlpatterns = [
    path('', views.configuracao_view, name='configuracao'),
]
