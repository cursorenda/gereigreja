# c:\Gereigreja\configuracao\forms.py
from django import forms
from .models import IgrejaConfiguracao

class IgrejaConfiguracaoForm(forms.ModelForm):
    class Meta:
        model = IgrejaConfiguracao
        fields = '__all__'
        widgets = {
            # Hierarquia e Nome
            'tipo_igreja': forms.Select(), # Usar Select padrão para choices
            'igreja_superior': forms.Select(), # Usar Select padrão para ForeignKey
            'nome_igreja': forms.TextInput(attrs={'placeholder': 'Nome da Igreja', 'size': '60'}),

            # Endereço
            'rua': forms.TextInput(attrs={'placeholder': 'Rua'}),
            'numero': forms.TextInput(attrs={'placeholder': 'Número'}),
            'complemento': forms.TextInput(attrs={'placeholder': 'Complemento'}),
            'bairro': forms.TextInput(attrs={'placeholder': 'Bairro'}),
            'cidade': forms.TextInput(attrs={'placeholder': 'Cidade'}), # NOVO
            'estado': forms.TextInput(attrs={'placeholder': 'Estado (UF ou Nome)'}), # NOVO
            'pais': forms.TextInput(attrs={'placeholder': 'País'}), # NOVO
            'cep': forms.TextInput(attrs={'placeholder': 'CEP'}),

            # Contato e Documentos
            'email': forms.EmailInput(attrs={'placeholder': 'E-mail'}),
            'cnpj': forms.TextInput(attrs={'placeholder': 'CNPJ'}),
            'telefone': forms.TextInput(attrs={'placeholder': 'Telefone'}),
            'celular': forms.TextInput(attrs={'placeholder': 'Celular'}),
            'site': forms.URLInput(attrs={'placeholder': 'Site'}),

            # Responsáveis
            'pastor_local': forms.TextInput(attrs={'placeholder': 'Pastor Local / Responsável'}),
            'pastor_regional': forms.TextInput(attrs={'placeholder': 'Pastor Regional'}),

            # Outros
            'moeda': forms.TextInput(attrs={'placeholder': 'Moeda (ex: BRL)'}),
            'observacoes': forms.Textarea(attrs={'placeholder': 'Observações', 'rows': 3}), # Ajuste opcional de linhas
            'logo1': forms.FileInput(),
            'logo2': forms.FileInput(),

            # Removidos do modelo, remover daqui também:
            # 'sub_sede': forms.TextInput(attrs={'placeholder': 'Sub-Sede'}),
            # 'congregacao': forms.TextInput(attrs={'placeholder': 'Congregação'}),
            # 'endereco': forms.TextInput(attrs={'placeholder': 'Endereço'}),
        }
        labels = {
            # Hierarquia e Nome
            'tipo_igreja': 'Tipo de Igreja',
            'igreja_superior': 'Igreja Superior (Sede/Regional)',
            'nome_igreja': 'Nome da Igreja',

            # Endereço
            'rua': 'Rua',
            'numero': 'Número',
            'complemento': 'Complemento',
            'bairro': 'Bairro',
            'cidade': 'Cidade', # NOVO
            'estado': 'Estado', # NOVO
            'pais': 'País', # NOVO
            'cep': 'CEP',

            # Contato e Documentos
            'email': 'E-mail',
            'cnpj': 'CNPJ',
            'telefone': 'Telefone',
            'celular': 'Celular',
            'site': 'Site',

            # Responsáveis
            'pastor_local': 'Pastor Local / Responsável',
            'pastor_regional': 'Pastor Regional',

            # Outros
            'moeda': 'Moeda',
            'observacoes': 'Observações',
            'logo1': 'Logo 1',
            'logo2': 'Logo 2',

            # Removidos do modelo, remover daqui também:
            # 'sub_sede': 'Sub-Sede',
            # 'congregacao': 'Congregação',
            # 'endereco': 'Endereço',
        }
