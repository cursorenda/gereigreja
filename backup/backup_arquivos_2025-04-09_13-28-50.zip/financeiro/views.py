from django.shortcuts import render, redirect, get_object_or_404
from .forms import DespesaForm, ReceitaForm, FechamentoCaixaForm
from datetime import datetime
from django.contrib import messages
from num2words import num2words
from django.db.models import Sum
from gerenciamento.models import Membro
from decimal import Decimal  # Import the Decimal class
from .models import Despesas, Receitas, FechamentoCaixa, CategoriaDespesa  # Import CategoriaDespesa
import locale
from configuracao.models import IgrejaConfiguracao


locale.setlocale(locale.LC_TIME, 'pt_BR.UTF-8')  # ou 'pt_BR' dependendo do seu sistema

def lista_despesas(request):
    """
    Lists all expenses, with the option to filter by date and category.
    """
    despesas = Despesas.objects.all().order_by('-data')  # Orders by descending date

    # Filters
    data_inicio = request.GET.get('data_inicio')
    data_fim = request.GET.get('data_fim')
    categoria = request.GET.get('categoria')

    if data_inicio:
        despesas = despesas.filter(data__gte=data_inicio)
    if data_fim:
        despesas = despesas.filter(data__lte=data_fim)
    if categoria:
        despesas = despesas.filter(categoria__id=categoria)

    categorias = CategoriaDespesa.objects.all()  # get the categories

    fechado = request.GET.get('fechado')
    if fechado:
        despesas = despesas.filter(fechado=True if fechado == 'true' else False)
    else:
        despesas = despesas.filter(fechado=False) # Filtro padrão para "Aberto"

    context = {
        'despesas': despesas,
        'categorias': categorias,
        'data_inicio': data_inicio,
        'data_fim': data_fim,
        'categoria_selecionada': categoria,
        'fechado_selecionado': fechado, # Adiciona o filtro selecionado ao contexto

    }

    
    return render(request, 'financeiro/despesas/lista_despesas.html', context)


def cadastrar_despesa(request):
    if request.method == 'POST':
        form = DespesaForm(request.POST)
        try:
            if form.is_valid():
                form.save()
                messages.success(request, 'Despesa cadastrada com sucesso!')
                return redirect('financeiro:lista_despesas')
            else:
                messages.error(request, 'Por favor, corrija os erros no formulário.')
        except Exception as e:  # Captura qualquer exceção
            messages.error(request, f'Erro ao cadastrar despesa: {e}')
            import logging
            logger = logging.getLogger(__name__)
            logger.exception(f'Erro ao cadastrar despesa: {e}') # Registra o erro no log
    else:
        form = DespesaForm()
    return render(request, 'financeiro/despesas/cadastrar_despesa.html', {'form': form})



def editar_despesa(request, pk):
    """
    Edits an existing expense.
    """
    despesa = get_object_or_404(Despesas, pk=pk)
    if request.method == 'POST':
        form = DespesaForm(request.POST, instance=despesa)
        if form.is_valid():
            form.save()
            return redirect('financeiro:lista_despesas')
    else:
        form = DespesaForm(instance=despesa)
    return render(request, 'financeiro/despesas/editar_despesa.html', {'form': form})


def lista_receitas(request):
    """
    Lists all revenues, with the option to filter by date and category.
    """
    receitas = Receitas.objects.all().order_by('-data')  # Orders by descending date

    # Filters
    data_inicio = request.GET.get('data_inicio')
    data_fim = request.GET.get('data_fim')
    categoria = request.GET.get('categoria')

    if data_inicio:
        receitas = receitas.filter(data__gte=data_inicio)
    if data_fim:
        receitas = receitas.filter(data__lte=data_fim)
    if categoria:
        receitas = receitas.filter(categoria=categoria)

    categorias = Receitas.objects.values_list('categoria', flat=True).distinct()

    fechado = request.GET.get('fechado')
    if fechado:
        receitas = receitas.filter(fechado=True if fechado == 'true' else False)
    else:
        receitas = receitas.filter(fechado=False) # Filtro padrão para "Aberto"

    context = {
        'receitas': receitas,
        'categorias': categorias,
        'data_inicio': data_inicio,
        'data_fim': data_fim,
        'categoria_selecionada': categoria,
        'fechado_selecionado': fechado, # Adiciona o filtro selecionado ao contexto

    }
    return render(request, 'financeiro/receitas/lista_receitas.html', context)


def cadastrar_receita(request):
    """
    Registers a new revenue.
    """
    if request.method == 'POST':
        form = ReceitaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Receita cadastrada com sucesso!')
            return redirect('financeiro:lista_receitas')  # Redirects to the list after registering
    else:
        form = ReceitaForm()
    return render(request, 'financeiro/receitas/cadastrar_receita.html', {'form': form})


def editar_receita(request, pk):
    """
    Edits an existing revenue.
    """
    receita = get_object_or_404(Receitas, pk=pk)
    if request.method == 'POST':
        form = ReceitaForm(request.POST, instance=receita)
        if form.is_valid():
            form.save()
            return redirect('financeiro:lista_receitas')
    else:
        form = ReceitaForm(instance=receita)
    return render(request, 'financeiro/receitas/editar_receita.html', {'form': form})



def relatorio_mensal_detalhe(request, pk):
    fechamento = get_object_or_404(FechamentoCaixa, pk=pk, status='fechado')

# Extraindo mês e ano do objeto fechamento
    mes_nome = fechamento.data_inicio.strftime("%B")
    ano = fechamento.data_inicio.strftime("%Y")

    receitas = Receitas.objects.filter(data__range=(fechamento.data_inicio, fechamento.data_fim), fechado=True)

    configuracao = IgrejaConfiguracao.objects.first()



    # Calcular totais de receitas por categoria
    dizimos = receitas.filter(categoria='dizimo').aggregate(total=Sum('valor'))['total'] or Decimal(0)
    ofertas_cultos = receitas.filter(categoria='oferta').aggregate(total=Sum('valor'))['total'] or Decimal(0)
    escola_dominical = receitas.filter(categoria='escola_dominical').aggregate(total=Sum('valor'))['total'] or Decimal(0)
    votos_campanha = receitas.filter(categoria='campanha').aggregate(total=Sum('valor'))['total'] or Decimal(0)
    total_entradas = dizimos + ofertas_cultos + escola_dominical + votos_campanha


    todas_categorias = CategoriaDespesa.objects.all()
    valores_despesas = {}
    for categoria in todas_categorias:
        valores_despesas[categoria.nome] = 0

    despesas_queryset = Despesas.objects.filter(data__range=(fechamento.data_inicio, fechamento.data_fim), fechado=True)
    for despesa in despesas_queryset:
        valores_despesas[despesa.categoria.nome] = despesa.valor

    total_saidas = sum(valores_despesas.values())
    valor_liquido = total_entradas - total_saidas
    valor_liquido_extenso = num2words(valor_liquido, to='currency', lang='pt_BR')
    
    bairro = fechamento.bairro if fechamento.bairro else "N/A" # More concise way

    print(f"Receitas: {receitas}")
    print(f"Dizimos: {dizimos}, Ofertas: {ofertas_cultos}, Escola: {escola_dominical}, Votos: {votos_campanha}")
    print(f"Total Entradas: {total_entradas}")

    context = {
        'fechamento': fechamento,
        'receitas': receitas,
        'despesas': valores_despesas,
        'total_entradas': total_entradas,
        'total_saidas': total_saidas,
        'valor_liquido': valor_liquido,
        'valor_liquido_extenso': valor_liquido_extenso,
        'data_atual': datetime.now().strftime('%d/%m/%Y'),
        'todas_categorias': todas_categorias,
        'dizimos': dizimos,
        'ofertas_cultos': ofertas_cultos,
        'escola_dominical': escola_dominical,
        'votos_campanha': votos_campanha,
        'mes_nome': mes_nome, # Adicionando mes_nome ao contexto
        'ano': ano, # Adicionando ano ao contexto
        'sub_sede': configuracao.sub_sede if configuracao else '',
        'congregacao': configuracao.congregacao if configuracao else '',
        'rua': configuracao.rua if configuracao else '',
        'bairro': configuracao.bairro if configuracao else '',
        'configuracao': configuracao,

    }
    return render(request, 'financeiro/relatorio_mensal.html', context)




def criar_fechamento_caixa(request):
    form = FechamentoCaixaForm()
    receitas = []
    despesas = []
    total_entradas = Decimal(0)
    total_saidas = Decimal(0)
    saldo_final = Decimal(0)
    data_inicio = None
    data_fim = None
    mensagem_erro = None

    if request.method == 'POST':
        form = FechamentoCaixaForm(request.POST)
        if 'action' in request.POST:
            if request.POST['action'] == 'buscar':
                if form.is_valid():
                    data_inicio = form.cleaned_data['data_inicio']
                    data_fim = form.cleaned_data['data_fim']
                    receitas, despesas, mensagem_erro = buscar_dados_fechamento(data_inicio, data_fim)
                    if mensagem_erro:
                        messages.error(request, mensagem_erro)
                    else:
                        total_entradas, total_saidas, saldo_final = calcular_totais_fechamento(receitas, despesas)
                else:
                    mensagem_erro = "Por favor, preencha as datas corretamente."
            elif request.POST['action'] == 'fechar':
                if form.is_valid():
                    data_inicio = form.cleaned_data['data_inicio']
                    data_fim = form.cleaned_data['data_fim']
                    sucesso, mensagem_erro = fechar_caixa(data_inicio, data_fim, total_entradas, total_saidas, saldo_final)
                    if sucesso:
                        messages.success(request, 'Caixa fechado com sucesso!')
                        return redirect('financeiro:lista_fechamentos_caixa')
                    else:
                        messages.error(request, mensagem_erro)
                else:
                    mensagem_erro = "Por favor, preencha as datas corretamente."

    context = {
        'form': form,
        'receitas': receitas,
        'despesas': despesas,
        'total_entradas': total_entradas,
        'total_saidas': total_saidas,
        'saldo_final': saldo_final,
        'data_inicio': data_inicio,
        'data_fim': data_fim,
        'mensagem_erro': mensagem_erro,
    }
    return render(request, 'financeiro/fechamentos/criar_fechamento_caixa.html', context)


def buscar_dados_fechamento(data_inicio, data_fim):
    try:
        receitas = Receitas.objects.filter(data__range=(data_inicio, data_fim), fechado=False)
        despesas = Despesas.objects.filter(data__range=(data_inicio, data_fim), fechado=False)
        return receitas, despesas, None
    except Exception as e:
        return [], [], f"Erro ao buscar dados: {e}"


def calcular_totais_fechamento(receitas, despesas):
    total_entradas = receitas.aggregate(Sum('valor'))['valor__sum'] or Decimal(0)
    total_saidas = despesas.aggregate(Sum('valor'))['valor__sum'] or Decimal(0)
    saldo_final = total_entradas - total_saidas
    return total_entradas, total_saidas, saldo_final


def fechar_caixa(data_inicio, data_fim, total_entradas, total_saidas, saldo_final):
    try:
        FechamentoCaixa.objects.create(
            data_inicio=data_inicio,
            data_fim=data_fim,
            total_entradas=total_entradas,
            total_saidas=total_saidas,
            saldo_final=saldo_final,
            status='fechado'
        )
        Receitas.objects.filter(data__range=(data_inicio, data_fim), fechado=False).update(fechado=True)
        Despesas.objects.filter(data__range=(data_inicio, data_fim), fechado=False).update(fechado=True)
        return True, None
    except Exception as e:
        return False, f"Erro ao fechar caixa: {e}"



def lista_fechamentos_caixa(request):
    fechamentos = FechamentoCaixa.objects.all().order_by('-data_fechamento')
    return render(request, 'financeiro/fechamentos/lista_fechamentos_caixa.html', {'fechamentos': fechamentos})




def lista_fechamentos_caixa(request):
    fechamentos = FechamentoCaixa.objects.all().order_by('-data_fechamento')
    # Adicionando a busca e cálculo dos totais
    for fechamento in fechamentos:
        receitas = Receitas.objects.filter(data__gte=fechamento.data_inicio, data__lte=fechamento.data_fim, fechado=True)
        despesas = Despesas.objects.filter(data__gte=fechamento.data_inicio, data__lte=fechamento.data_fim, fechado=True)
        fechamento.total_entradas = receitas.aggregate(Sum('valor'))['valor__sum'] or 0
        fechamento.total_saidas = despesas.aggregate(Sum('valor'))['valor__sum'] or 0
        fechamento.saldo_final = fechamento.total_entradas - fechamento.total_saidas

    return render(request, 'financeiro/fechamentos/lista_fechamentos_caixa.html', {'fechamentos': fechamentos})


def detalhe_fechamento_caixa(request, pk):
    fechamento = get_object_or_404(FechamentoCaixa, pk=pk)

    # Calcula os totais novamente usando as datas do fechamento
    receitas = Receitas.objects.filter(data__gte=fechamento.data_inicio, data__lte=fechamento.data_fim, fechado=True)
    despesas = Despesas.objects.filter(data__gte=fechamento.data_inicio, data__lte=fechamento.data_fim, fechado=True)
    total_entradas = receitas.aggregate(Sum('valor'))['valor__sum'] or Decimal(0)
    total_saidas = despesas.aggregate(Sum('valor'))['valor__sum'] or Decimal(0)
    saldo_final = total_entradas - total_saidas

    context = {
        'fechamento': fechamento,
        'receitas': receitas,
        'despesas': despesas,
        'total_entradas': total_entradas,
        'total_saidas': total_saidas,
        'saldo_final': saldo_final,
    }

    return render(request, 'financeiro/fechamentos/detalhe_fechamento_caixa.html', context)

def editar_fechamento_caixa(request, pk):
    """
    Edits an existing cashier closing.
    """
    fechamento = get_object_or_404(FechamentoCaixa, pk=pk)

    if request.method == 'POST':
        form = FechamentoCaixaForm(request.POST, instance=fechamento)
        if form.is_valid():
            fechamento = form.save(commit=False)
            # Get data from the form
            data_inicio = fechamento.data_inicio
            data_fim = fechamento.data_fim

            # Calculate totals of revenues and expenses
            total_entradas = Receitas.objects.filter(data__gte=data_inicio, data__lte=data_fim, fechado=True).aggregate(Sum('valor'))['valor__sum'] or 0
            total_saidas = Despesas.objects.filter(data__gte=data_inicio, data__lte=data_fim, fechado=True).aggregate(Sum('valor'))['valor__sum'] or 0

            # Calculate final balance
            saldo_final = total_entradas - total_saidas

            # Assign the values to the closing object
            fechamento.total_entradas = total_entradas
            fechamento.total_saidas = total_saidas
            fechamento.saldo_final = saldo_final
            fechamento.status = 'reaberto'
            fechamento.save()
            return redirect('financeiro:lista_fechamentos_caixa')
    else:
        form = FechamentoCaixaForm(instance=fechamento)

    return render(request, 'financeiro/fechamentos/editar_fechamento_caixa.html', {'form': form, 'fechamento': fechamento})



class FechamentoCaixaService:
    def __init__(self, data_inicio, data_fim):
        self.data_inicio = data_inicio
        self.data_fim = data_fim

    def get_receitas_and_despesas(self):
        try:
            receitas = Receitas.objects.filter(data__range=(self.data_inicio, self.data_fim), fechado=False)
            despesas = Despesas.objects.filter(data__range=(self.data_inicio, self.data_fim), fechado=False)
            return receitas, despesas, None  # Retorna None para mensagem de erro
        except Exception as e:
            return [], [], f"Erro ao buscar dados: {e}"

    def calculate_totals(self, receitas, despesas):
        total_entradas = receitas.aggregate(Sum('valor'))['valor__sum'] or Decimal(0)
        total_saidas = despesas.aggregate(Sum('valor'))['valor__sum'] or Decimal(0)
        saldo_final = total_entradas - total_saidas
        return total_entradas, total_saidas, saldo_final

    def create_fechamento(self, total_entradas, total_saidas, saldo_final):
        try:
            fechamento = FechamentoCaixa.objects.create(
                data_inicio=self.data_inicio,
                data_fim=self.data_fim,
                total_entradas=total_entradas,
                total_saidas=total_saidas,
                saldo_final=saldo_final,
                status='fechado'
            )
            Receitas.objects.filter(data__range=(self.data_inicio, self.data_fim), fechado=False).update(fechado=True)
            Despesas.objects.filter(data__range=(self.data_inicio, self.data_fim), fechado=False).update(fechado=True)
            return fechamento, None
        except Exception as e:
            return None, f"Erro ao criar fechamento: {e}"
