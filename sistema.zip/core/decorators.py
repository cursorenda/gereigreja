from functools import wraps
from django.shortcuts import redirect
from django.urls import reverse
from django.contrib import messages
# Supondo que get_organizacao_or_error e AssinaturaOrganizacao estão acessíveis
# Se get_organizacao_or_error estiver em configuracao.views, você precisará importá-la
# from configuracao.views import get_organizacao_or_error (cuidado com import circular se este decorator for usado lá)
# Seria melhor mover get_organizacao_or_error para um utils.py

def verificar_assinatura_valida(view_func):
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        # Esta é uma simplificação. Idealmente, get_organizacao_or_error seria chamada aqui
        # ou uma lógica similar para obter a organização e sua assinatura.
        # Por agora, vamos assumir que a view_func chamará get_organizacao_or_error.
        # O objetivo deste decorator é verificar o status APÓS get_organizacao_or_error ter sido chamada
        # e a organização estar disponível, ou fazer a verificação aqui.

        # Para este exemplo, vamos focar no redirecionamento se a assinatura não for válida.
        # A view_func ainda será responsável por chamar get_organizacao_or_error para obter a org.
        if hasattr(request.user, 'perfil') and request.user.perfil.organizacao:
            organizacao = request.user.perfil.organizacao
            try:
                assinatura = organizacao.assinatura
                status_validos = ['ativa', 'gratuita']
                if not (assinatura.status in status_validos or assinatura.is_periodo_cortesia_valido()):
                    if request.path != reverse('configuracao:gerenciar_assinatura'):
                        messages.warning(request, f"Sua assinatura está {assinatura.get_status_display()}. Por favor, regularize sua situação ou ative sua cortesia.")
                        return redirect('configuracao:gerenciar_assinatura')
            except organizacao._meta.get_field('assinatura').related_model.DoesNotExist: # AssinaturaOrganizacao.DoesNotExist
                if not organizacao.verificar_elegibilidade_plano_gratuito():
                    if request.path != reverse('configuracao:gerenciar_assinatura'):
                        messages.warning(request, "Sua organização não possui uma assinatura ativa. Por favor, escolha um plano ou ative sua cortesia.")
                        return redirect('configuracao:gerenciar_assinatura')
        return view_func(request, *args, **kwargs)
    return _wrapped_view